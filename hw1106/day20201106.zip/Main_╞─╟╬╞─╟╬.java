package SWEA_파핑파핑지뢰찾기;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main {
	private static int N, Answer;
	private static int[][] map;
	private static boolean[][] visited;
	private static int[] di = { -1, -1, -1, 0, 1, 1, 1, 0 };
	private static int[] dj = { -1, 0, 1, 1, 1, 0, -1, -1 };

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		StringBuilder sb = new StringBuilder();
		int T = Integer.parseInt(st.nextToken());
		for (int test_case = 1; test_case <= T; test_case++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			map = new int[N][N];
			visited = new boolean[N][N];
			Answer = 0;
			for (int i = 0; i < N; i++) {
				String[] line = br.readLine().split("");
				for (int j = 0; j < N; j++) {
					if (line[j].equals(".")) {
						map[i][j] = 9;
					} else if (line[j].equals("*")) {
						map[i][j] = -1;
					}
				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (map[i][j] == 9) {
						boolean b = false;
						Queue<Point> queue = new LinkedList<Point>();
						queue.offer(new Point(i, j));
						while (!queue.isEmpty()) {
							int cnt = 0;
							Point p = queue.poll();
							if (!visited[p.i][p.j]) {
								for (int k = 0; k < 8; k++) {
									int ni = p.i + di[k];
									int nj = p.j + dj[k];
									if (ni >= 0 && ni < N && nj >= 0 && nj < N && map[ni][nj] == -1) {
										cnt++;
										break;
									}
								}
								if (cnt == 0) {
									if(!b) {
										Answer++;
									}
									b= true;
									map[i][j] = cnt;
									visited[i][j] = true;
									for (int k = 0; k < 8; k++) {
										int ni = p.i + di[k];
										int nj = p.j + dj[k];
										if (ni >= 0 && ni < N && nj >= 0 && nj < N && map[ni][nj] == 9) {
											map[ni][nj] = 0;
											queue.offer(new Point(ni, nj));
										}
									}
								}
							}
						}
					}
				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (map[i][j] == 9) {
						Answer++;
					}
				}
			}
			sb.append("#" + test_case + " " + Answer + "\n");
		}
		System.out.println(sb);
	}
	public static class Point {
		int i, j;

		Point(int i, int j) {
			this.i = i;
			this.j = j;
		}

	}
}
