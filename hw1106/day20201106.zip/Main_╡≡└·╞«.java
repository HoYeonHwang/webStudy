package SWEA_디저트;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	private static int N, Answer, map[][];
	private static boolean[][] visited;
	private static int[] di = { 1, 1, -1, -1 };
	private static int[] dj = { -1, 1, 1, -1 };

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		StringBuilder sb = new StringBuilder();
		int T = Integer.parseInt(st.nextToken());
		for (int test_case = 1; test_case <= T; test_case++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			map = new int[N][N];
			visited = new boolean[N][N];
			Answer = -1;
			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(st.nextToken());
				}
			}
			move();
			sb.append("#" + test_case + " " + Answer + "\n");
		}
		System.out.println(sb);
	}

	private static void move() {
		for (int i = 0; i < N - 1; i++) {
			for (int j = 1; j < N - 1; j++) {
				visited[i][j] = true;
				dfs(i, j, i, j, 1, 0);
				visited[i][j] = false;
			}
		}
	}

	private static void dfs(int i, int j, int si, int sj, int cnt, int dir) {
		for (int k = 0; k < 2; k++) {
			int ni = i + di[dir];
			int nj = j + dj[dir];
			if (dir + k == 4) {
				return;
			}
			dir = (dir + k) % 4;
			if (ni >= 0 && ni < N && nj >= 0 && nj < N) {
				if (si == ni && sj == nj) {
					Answer = Math.max(Answer, cnt);
					return;
				}
				dfs(ni, nj, si, sj, cnt + 1, dir);
			}
		}

	}
}
