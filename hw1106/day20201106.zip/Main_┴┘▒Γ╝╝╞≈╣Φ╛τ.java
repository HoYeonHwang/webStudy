package 줄기세포배양;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main {
	private static int N, M, K, Answer, map[][][];
	private static int[] di = { 0, -1, 0, 1 };
	private static int[] dj = { -1, 0, 1, 0 };
	private static Queue<Point> queue;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		StringBuilder sb = new StringBuilder();
		int T = Integer.parseInt(st.nextToken());
		for (int test_case = 1; test_case <= T; test_case++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			K = Integer.parseInt(st.nextToken());
			queue = new LinkedList<Point>();
			Answer =0;
			map = new int[K * 2 + N][K * 2 + M][2];
			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < M; j++) {
					map[K + i][K + j][0] = Integer.parseInt(st.nextToken());
				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
					if (map[K + i][K + j][0] != 0) {
						int k = map[K + i][K + j][0];
						queue.offer(new Point(K + i, K + j, -1, k, 0));
					}
				}
			}

			for (int i = 1; i <= K; i++) {
				bfs(i);
			}
			while(!queue.isEmpty()) {
				Point check = queue.poll();
				if(check.d == map[check.i][check.j][0]) {
					Answer++;
				}
			}
			sb.append("#" + test_case + " " + Answer + "\n");
		}
		System.out.println(sb);

	}

	private static void bfs(int i) {
		int size = queue.size();
		for (int s = 0; s < size; s++) {
			Point temp = queue.poll();
			if (temp.d == 1 && temp.nt == 0) {
				for (int k = 0; k < 4; k++) {
					int ni = temp.i + di[k];
					int nj = temp.j + dj[k];
					if (map[ni][nj][0] != 0) {
						if (map[ni][nj][1] < i) {
							continue;
						} else if (map[ni][nj][1] == i) {
							if (map[ni][nj][0] < temp.t) {
								map[ni][nj][0] = temp.t;
								queue.offer(new Point(ni, nj, -1, temp.t, 0));
							}
						}
					} else {
						map[ni][nj][0] = temp.t;
						map[ni][nj][1] = i;
						queue.offer(new Point(ni, nj, -1, temp.t, 0));
					}
				}
			}
			int tnt = temp.nt+1;
			if (tnt == temp.t) {
				if (temp.d == 1) {
					continue;
				} else if (temp.d == -1) {
					int dd = 1;
					tnt = 0;
					queue.offer(new Point(temp.i, temp.j, dd, temp.t, temp.nt+1));
				}
			} else {
				queue.offer(new Point(temp.i, temp.j, temp.d, temp.t, temp.nt+1));
			}
		}

	}

	public static class Point {
		int i, j, d, t, nt;

		Point(int i, int j, int d, int t, int nt) {
			this.i = i;
			this.j = j;
			this.d = d;
			this.t = t;
			this.nt = nt;
		}
	}
}
