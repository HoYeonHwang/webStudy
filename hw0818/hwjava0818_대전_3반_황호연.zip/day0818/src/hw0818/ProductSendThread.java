package hw0818;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

// 현재 모든 상품 정보를 서버에게 전달하기 - BufferedReader로 그냥 스트링 전송해도 됨.
public class ProductSendThread implements Runnable {
	ArrayList<Product> pro = new ArrayList<Product>();

	public static void main(String[] args) {

	}

	public ProductSendThread(ArrayList<Product> result) {
		// TODO Auto-generated constructor stub
		this.pro = result;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		String host = "localhost";
		int port = 9999;

		try (Socket socket = new Socket(host, port)) {
			OutputStream output = socket.getOutputStream();
			for (Product p : pro) {
				String sendnumber = " productNumber= " + p.getProductNumber();
				output.write(sendnumber.getBytes());
				String sendprice = " productNumber= " + p.getPrice();
				output.write(sendprice.getBytes());
				String sendquantity = " productNumber= " + p.getPrice();
				output.write(sendquantity.getBytes());
				String sendName = " productNumber= " + p.getProductName();
				output.write(sendName.getBytes());
				String send = "\t";
				output.write(send.getBytes());
			}

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
