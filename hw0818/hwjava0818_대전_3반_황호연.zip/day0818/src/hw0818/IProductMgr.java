package hw0818;

import java.util.ArrayList;

public interface IProductMgr {
	public void addData(Product p) throws DuplicateException;
	public ArrayList<Product> search() ;
	public Product searchNumber(String number) throws CodeNotFoundException;
	public ArrayList<Product> searchName(String name) ;
	public ArrayList<Product> searchType(boolean type) ;
	public ArrayList<Product> searchRefCapacity(int capacity) throws ProductNotFoundException;
	public ArrayList<Product> searchTvSize(int size) throws ProductNotFoundException;
	public boolean changePrice(String number, int price);
	public boolean deleteProduct(String number);
	public int searchPriceSum();
}

class DuplicateException extends Exception{

	public DuplicateException(String msg) {
		super(msg);
	}
}

class CodeNotFoundException extends Exception{

	public CodeNotFoundException(String msg) {
		super(msg);
	}
}

class ProductNotFoundException extends Exception{

	public ProductNotFoundException(String msg) {
		super(msg);
	}
}