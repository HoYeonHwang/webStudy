package hw0818;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

//product.dat 파일에 현재 객체 내용들을 저장하기. - ObjectOutputStream
public class ProductSaveThread implements Runnable, Serializable {
	ArrayList<Product> pro = new ArrayList<Product>();
    private static final long serialVersionUID = 1L;

	public ProductSaveThread(ArrayList<Product> pro)  {
		this.pro = pro;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		ObjectOutputStream os = null;
		try {
			os = new ObjectOutputStream(new FileOutputStream("Product.dat"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Product product : pro) {
			try {
				os.writeObject(product);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("complete");
		try {
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
