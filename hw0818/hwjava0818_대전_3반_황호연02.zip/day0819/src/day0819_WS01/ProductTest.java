package day0819_WS01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ProductTest {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ProductMgrImpl mgr = ProductMgrImpl.getInstance();
		
		while(true) {
			menu();
			int menuNum = Integer.parseInt(br.readLine());
			if(menuNum == 0) break;
			
			Product b;
			ArrayList<Product> result;
			String word;
			int num;
			boolean finish;
			String []st;
			
			switch(menuNum) {
			case 1:
				System.out.println("상품 정보를 입력하세요. (상품 번호,가격,수량,상품명,사이즈)");
				st = br.readLine().split(",");
				if(Integer.parseInt(st[4]) >= 100) {
					b = new Refrigerator(st[0], Integer.parseInt(st[1]), Integer.parseInt(st[2]), st[3], Integer.parseInt(st[4]));
					try{
						mgr.addData(b);
					}catch(DuplicateException e) {
						e.printStackTrace();
					}
				}
				else {
					b = new Tv(st[0], Integer.parseInt(st[1]), Integer.parseInt(st[2]), st[3], Integer.parseInt(st[4]));
					try{
						mgr.addData(b);
					}catch(DuplicateException e) {
						e.printStackTrace();
					}
				}
				break;
			case 2:
				System.out.println("------------------------------------------------------------");
				result = mgr.search();
				if(result.size() == 0) System.out.println("검색결과가 없습니다.");
				else {
					for(Product product : result){
						System.out.println(product.toString());
					}					
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 3:
				System.out.println("검색하고자 하는 상품번호를 입력하세요. ");
				word = br.readLine();
				System.out.println("------------------------------------------------------------");
				try{
					b = mgr.searchNumber(word);
					System.out.println(b.toString());
				}catch(CodeNotFoundException e) {
					e.printStackTrace();
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 4:
				System.out.println("검색하고자 하는 상품명을 입력하세요. ");
				word = br.readLine();
				System.out.println("------------------------------------------------------------");
				result = mgr.searchName(word);
				if(result.size() == 0) System.out.println("검색결과가 없습니다.");
				else {
					for(Product product : result){
						System.out.println(product.toString());
					}					
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 5:
				System.out.println("------------------------------------------------------------");
				result = mgr.searchType(true);
				if(result.size() == 0) System.out.println("검색결과가 없습니다.");
				else {
					for(Product product : result){
						System.out.println(product.toString());
					}					
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 6:
				System.out.println("------------------------------------------------------------");
				result = mgr.searchType(false);
				if(result.size() == 0) System.out.println("검색결과가 없습니다.");
				else {
					for(Product product : result){
						System.out.println(product.toString());
					}					
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 7:
				System.out.println("검색하고자 하는 냉장고 용량을 입력하세요. ");
				num = Integer.parseInt(br.readLine());
				System.out.println("------------------------------------------------------------");
				try{
					result = mgr.searchRefCapacity(num);
					for(Product product : result){
						System.out.println(product.toString());					
					}
				}catch(ProductNotFoundException e){
					e.printStackTrace();
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 8:
				System.out.println("검색하고자 하는 TV 사이즈를 입력하세요. ");
				num = Integer.parseInt(br.readLine());
				System.out.println("------------------------------------------------------------");
				try{
					result = mgr.searchTvSize(num);
					for(Product product : result){
						System.out.println(product.toString());					
					}
				}catch(ProductNotFoundException e){
					e.printStackTrace();
				}
				System.out.println("------------------------------------------------------------");
				break;
			case 9:
				System.out.println("상품번호와 변경하려는 가격을 입력하세요.(상품번호,가격) ");
				st = br.readLine().split(",");
				System.out.println("------------------------------------------------------------");
				finish = mgr.changePrice(st[0], Integer.parseInt(st[1]));
				if(finish) System.out.println("변경 되었습니다.");
				else System.out.println("상품번호를 확인하세요.");
				System.out.println("------------------------------------------------------------");
				break;
			case 10:
				System.out.println("삭제하고자 하는 상품번호를 입력하세요. ");
				word = br.readLine();
				System.out.println("------------------------------------------------------------");
				finish = mgr.deleteProduct(word);
				if(finish) System.out.println("삭제 되었습니다.");
				else System.out.println("상품번호를 확인하세요.");
				System.out.println("------------------------------------------------------------");
				break;
			case 11:
				System.out.println("------------------------------------------------------------");
				num = mgr.searchPriceSum();
				System.out.println("전체 금액 합계는 " + num + "원 입니다.");
				System.out.println("------------------------------------------------------------");
				break;
			case 12: // 12, 13  두개의 케이스 실행되게 하는게 핵심!
				new Thread(new ProductSaveThread()).start();
				break;
			case 13:
				new Thread(new ProductSendThread()).start();
				break;
			default :
				System.out.println("잘못된 번호입니다. 다시 입력해주세요.");
				break;
			}
		}
		
		System.out.println("프로그램이 종료 되었습니다.");
	}
	
	static void menu() {
		System.out.println("<< 상품 관리 프로그램>>>");
		System.out.println("1. 데이터 추가");
		System.out.println("2. 데이터 전체 검색");
		System.out.println("3. 상품번호로 정보를 검색 ");
		System.out.println("4. 상품명으로 정보를 검색");
		System.out.println("5. TV만 검색");
		System.out.println("6. 냉장고만 검색");
		System.out.println("7. 냉장고 용랑으로 검색");
		System.out.println("8. TV 사이즈로 검색");
		System.out.println("9. 상품의 가격 변경");
		System.out.println("10.상품 삭제");
		System.out.println("11.전체 재고 상품 금액 합계");
		System.out.println("12.현재 상품정보 파일로 저장");
		System.out.println("13.현재 상품정보 서버에게 전송");
		System.out.println("0. 종료 ");
		System.out.println("------------------------------------------------------------");
		System.out.print("원하는 번호를 선택하세요. ");
	}
}

//
// 1001,100000,5,삼성냉장고,500
// 1002,150000,3,냉장고,400
// 2001,50000,10,삼성TV,30
// 2002,30000,5,TV,20