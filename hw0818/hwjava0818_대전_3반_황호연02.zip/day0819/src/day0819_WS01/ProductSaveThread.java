package day0819_WS01;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

//product.dat 파일에 현재 객체 내용들을 저장하기. - ObjectOutputStream
public class ProductSaveThread implements Runnable {

	@Override
	public void run() {
		ObjectOutputStream os = null;
		try {
			os = new ObjectOutputStream(new FileOutputStream("product.dat"));
			ProductMgrImpl mgr = ProductMgrImpl.getInstance();
			
			List<Product> list = mgr.search();
			for(Product p : list) {
				os.writeObject(p);
			}
			System.out.println("파일 저장이 완료되었습니다.");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}