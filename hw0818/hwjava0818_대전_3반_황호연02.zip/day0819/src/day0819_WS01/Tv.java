package day0819_WS01;

import java.io.Serializable;

public class Tv extends Product{
	private int size;

	public Tv(String productNumber, int price, int quantity, String productName, int size) {
		super(productNumber, price, quantity, productName);
		this.size = size;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}

	@Override
	public String toString() {
		return super.toString() + " size=" + size + "]";
	}
	
	
}
