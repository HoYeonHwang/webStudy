package day0819_WS01;

import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {
	// singleton pattern
	private static ProductMgrImpl instance = new ProductMgrImpl();
	private ProductMgrImpl() {}
	public static ProductMgrImpl getInstance() {
		return instance;
	}
////////////////////////////////////////////////////////////////////////
	private ArrayList<Product> productList = new ArrayList<>();
	
	@Override
	public void addData(Product p) throws DuplicateException {
		for(Product product : productList) {
			if(product.getProductName().equals(p.getProductName())) {
				throw new DuplicateException("이미 존재하는 상품입니다.");
			}
		}
		productList.add(p);
	}

	@Override
	public ArrayList<Product> search() {
		return productList;
	}

	@Override
	public Product searchNumber(String number) throws CodeNotFoundException {
		Product result = null;
		for(Product p : productList) {
			if(p.getProductNumber().equals(number)) {
				result = p;
				break;
			}
		}
		if(result == null)
			throw new CodeNotFoundException("상품 번호가 존재하지 않습니다.");
		return result;
	}

	@Override
	public ArrayList<Product> searchName(String name) {
		ArrayList<Product> result = new ArrayList<>();
		for(Product p : productList) {
			if(p.getProductName().equals(name)) {
				result.add(p);
			}
		}
		return result;
	}

	@Override
	public ArrayList<Product> searchType(boolean type) {
		ArrayList<Product> result = new ArrayList<>();
		if(type) {
			for(Product p : productList) {
				if(p instanceof Tv) {
					result.add(p);
				}
			}
		}else {
			for(Product p : productList) {
				if(p instanceof Refrigerator) {
					result.add(p);
				}
			}
		}
		return result;
	}

	@Override
	public ArrayList<Product> searchRefCapacity(int capacity) throws ProductNotFoundException {
		ArrayList<Product> result = new ArrayList<>();
		for(Product p : productList) {
			if(p instanceof Refrigerator && ((Refrigerator)p).getCapacity() >= capacity) {
				result.add(p);
			}
		}
		if(result.size() == 0)
			throw new ProductNotFoundException("상품이 존재 하지 않습니다.");
		return result;
	}

	@Override
	public ArrayList<Product> searchTvSize(int size) throws ProductNotFoundException {
		ArrayList<Product> result = new ArrayList<>();
		for(Product p : productList) {
			if(p instanceof Tv && ((Tv)p).getSize() >= size) {
				result.add(p);
			}
		}
		if(result.size() == 0)
			throw new ProductNotFoundException("원하시는 상품이 존재 하지 않습니다.");
		return result;
	}

	@Override
	public boolean changePrice(String number, int price) {
		for(Product p : productList) {
			if(p.getProductNumber().equals(number)) {
				p.setPrice(price);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteProduct(String number) {
		for(int i = 0; i < productList.size(); i++) {
			if(productList.get(i).getProductNumber().contentEquals(number)) {
				productList.remove(i);
				return true;
			}
		}
		return false;
	}

	@Override
	public int searchPriceSum() {
		int sum = 0;
		for(Product p : productList) {
			sum += p.getPrice();
		}
		return sum;
	}
}
