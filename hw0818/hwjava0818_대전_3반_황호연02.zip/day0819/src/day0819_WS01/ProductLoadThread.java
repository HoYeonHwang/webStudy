package day0819_WS01;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

//product.dat 파일에 현재 객체 내용들을 저장하기. - ObjectOutputStream
public class ProductLoadThread implements Runnable {

	@Override
	public void run() {
		ObjectInputStream os = null;
		try {
			os = new ObjectInputStream(new FileInputStream("product.dat"));
			ProductMgrImpl mgr = ProductMgrImpl.getInstance();
			mgr.search().clear();
			while(true) {
				mgr.addData((Product) os.readObject());
			}
			
		} catch (EOFException e) {
			System.out.println("complete!");
		} catch (IOException e) {
			System.out.println("파일 읽기가 완료되었습니다.");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DuplicateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}