package day0819_WS01;

import java.io.Serializable;

public class Product implements Serializable{
	private int price, quantity;
	private String productNumber, productName;
	
	public Product(String productNumber, int price, int quantity, String productName) {
		this.productNumber = productNumber;
		this.price = price;
		this.quantity = quantity;
		this.productName = productName;
	}
	
	public String getProductNumber() {
		return productNumber;
	}
	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@Override
	public String toString() {
		return "Product [productNumber=" + productNumber + ", price=" + price + ", quantity=" + quantity
				+ ", productName=" + productName + "]";
	}
}
