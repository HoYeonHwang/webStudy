package day0819_WS01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ProductServer {
	public static void main(String[] args) throws IOException {
		// 이곳을 작성해서 13번 기능이 실행됐을 때 전달받은 상품이 그냥 콘솔에 쭉 뿌려지면 끝!

		ServerSocket serverSocket = new ServerSocket(7777);

		while (true) {
			try {
				System.out.println("server waiting........");
				Socket socket = serverSocket.accept();
				System.out.println("client connect!!");

				BufferedReader br = new BufferedReader
						(new InputStreamReader(socket.getInputStream()));
				
				while(true) {
					String recive = br.readLine();
					if(recive==null) {
						throw new IOException();
					}
					else {
						System.out.println(recive);
					}
				}
				
			} catch (IOException e) {
				System.out.println("현재 클라이언트 데이터 수신 완료");
			}
		}
	}
}
