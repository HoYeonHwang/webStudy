package day0819_WS01;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

// 현재 모든 상품 정보를 서버에게 전달하기 - BufferedReader로 그냥 스트링 전송해도 됨.
public class ProductSendThread implements Runnable {

	@Override
	public void run() {

		Socket socket = null;
		try {
			socket = new Socket(InetAddress.getByName("192.168.207.69"), 7777);

			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			ProductMgrImpl mgr = ProductMgrImpl.getInstance();

			for (Product p : mgr.searchType(true)) {
				bw.write(p.toString()+"\n");
			}
			for (Product p : mgr.searchType(false)) {
				bw.write(p.toString()+"\n");
			}
			
			bw.flush();
			System.out.println("상품정보 서버에 전송 완료");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (socket != null) {
				try {
					socket.close();

				} catch (IOException e) {
					// TODO: handle exception
					e.printStackTrace();

				}
			}
		}

	}

}
