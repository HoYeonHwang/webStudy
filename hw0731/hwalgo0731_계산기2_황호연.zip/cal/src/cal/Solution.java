package cal;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class Solution {
	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);

		for (int test_case = 1; test_case <= 10; test_case++) {
			Stack<String> cal_stack = new Stack<String>();
			Stack<String> op_stack = new Stack<String>();
			int N = sc.nextInt();
			String input = new String();
			String[] str = new String[N];
			String[] cal = new String[N];
			int cnt = -1;
			sc.nextLine();
			input = sc.next();
			str = input.split("");

			for (int i = 0; i < N; i++) {
				if (value_check(str[i])) {
					cal[++cnt] = str[i];
				} else {
					if (str[i].equals("+")) {
						if (op_stack.isEmpty() == true) {
							op_stack.push("+");
						} else if(op_stack.isEmpty()==false){
							for (int k = op_stack.size(); k >0; k--) {
								cal[++cnt] = op_stack.pop();
							}
							op_stack.push("+");
						}
					} else if(str[i].equals("*")){
						op_stack.push("*");
					}
				}
			}
			for (int i = op_stack.size(); i >0; i--) {
				cal[++cnt] = op_stack.pop();
			}
			for(int i=0;i<N;i++) {
				if(value_check(cal[i])) {
					cal_stack.push(cal[i]);
				}
				else {
					int x,y;
					if(cal[i]=="+") {
						
						x=Integer.parseInt(cal_stack.pop());
						y=Integer.parseInt(cal_stack.pop());
						cal_stack.push(Integer.toString(x+y));
					}
					else if(cal[i]=="*") {
						x=Integer.parseInt(cal_stack.pop());
						y=Integer.parseInt(cal_stack.pop());
						cal_stack.push(Integer.toString(x*y));
					}
				}
			}
			System.out.println("#"+test_case+" "+cal_stack.pop());
		}
	}
	private static boolean value_check(String s) {
		try {
			Double.parseDouble(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}