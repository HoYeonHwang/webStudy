package day0806;

import java.util.Scanner;

public class hw_2961_도영이가만든맛있는음식 {
	static int f_size = 11, Answer, N;
	static int[] S = new int[f_size];
	static int[] B = new int[f_size];
	static boolean[] visited;
	static food[] f;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		Answer = Integer.MAX_VALUE;
		
		f=new food[N];
		visited = new boolean[N];

		for (int i = 0; i < N; i++) {
			S[i] = sc.nextInt();
			B[i] = sc.nextInt();
			f[i]= new food(S[i],B[i]);
		}
		recur(f,0);
		System.out.println(Answer);
	}

	private static void recur(food[] f, int index) {
		if(index==N) {
			int temp;
			temp = print(f);
			if(Answer>temp) {
				Answer=temp;
			}
			return;
		}
			visited[index]=true;
			recur(f,index+1);
			visited[index]=false;
			recur(f,index+1);

	}
	private static int print(food[] f) {
		int S=1;
		int B=0;
		for(int i=0;i<N;i++) {
			if(visited[i]) {
				S=S*f[i].svalue;
				B=B+f[i].bvalue;
			}
		}
		if(S==1&&B==0) {
			return Integer.MAX_VALUE;
		}
		return Math.abs(S-B);
	}

	public static class food{
		int svalue,bvalue;
		food(int x,int y){
			svalue=x;
			bvalue=y;
		}
	}
}
