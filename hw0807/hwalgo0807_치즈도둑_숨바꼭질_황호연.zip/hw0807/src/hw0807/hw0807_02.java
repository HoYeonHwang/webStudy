package hw0807;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class hw0807_02 {
	private static int subin, sister,Answer;
	private static int[] visited=new int[100001];
	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(bf.readLine());
		subin = Integer.parseInt(st.nextToken());
		sister = Integer.parseInt(st.nextToken());
		bfs();
		
	}
	public static void bfs() {
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.offer(subin);
		visited[subin]=1;
		int current;
		
		while(!queue.isEmpty()) {
			current = queue.poll();
			if(current==sister) {
				break;
			}
			if(current+1<=100000&&visited[current+1]==0) {
				queue.offer(current+1);
				visited[current+1]=visited[current]+1;
			}
			if(current-1>=0&&visited[current-1]==0) {
				queue.offer(current-1);
				visited[current-1]=visited[current]+1;
			}
			if(current*2<=100000&&visited[current*2]==0) {
				queue.offer(current*2);
				visited[current*2]=visited[current]+1;
			}
		}
		System.out.println(visited[sister]-1);
	}
}
