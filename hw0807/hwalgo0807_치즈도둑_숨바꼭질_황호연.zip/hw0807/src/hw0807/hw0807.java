package hw0807;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class hw0807 {
	private static int[] deli = { -1, 0, 1, 0 };
	private static int[] delj = { 0, 1, 0, -1 };
	private static int[][] map;
	private static boolean[][] visited;
	private static int T, N, Answer,day,last;

	public static void main(String[] args) throws IOException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(bf.readLine());
		T = Integer.parseInt(st.nextToken());
		for (int test_case = 1; test_case <= T; test_case++) {
			Answer=0;
			N = Integer.parseInt(bf.readLine());
			map = new int[N][N];
			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(bf.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(st.nextToken());
					if(map[i][j]>last) {
						last=map[i][j];
					}
				}
			}

			day = 0;
			while (day<last) {
				visited=new boolean[N][N];
				int ans = 0;
				for (int i = 0; i < N; i++) {
					for (int j = 0; j < N; j++) {
						if (map[i][j] > day && !visited[i][j]) {
							bfs(i, j);
							ans++;
						}
					}
				}
				if(Answer<ans) {
					Answer=ans;
				}
				int cnt = 0;
				for (int i = 0; i < N; i++) {
					for (int j = 0; j < N; j++) {
						if (map[i][j] == 0) {
							cnt++;
						}
					}
				}
				if (cnt == N * N) {
					break;
				}
				day++;
			}
			System.out.println("#"+test_case+" "+Answer);
		}
	}
	static void bfs(int si, int sj) {
		Queue<Cheese> queue = new LinkedList<Cheese>();
		queue.offer(new Cheese(si, sj));
		visited[si][sj] = true;
		while (!queue.isEmpty()) {
			Cheese current = queue.poll();
			for (int k = 0; k < 4; k++) {
				int ni = current.i + deli[k];
				int nj = current.j + delj[k];
				if (ni >= 0 && ni < N && nj >= 0 && nj < N && !visited[ni][nj]&&map[ni][nj]>day) {
					queue.offer(new Cheese(ni, nj));
					visited[ni][nj] = true;
				}
			}
		}
	}

	static class Cheese {
		int i, j;

		Cheese(int i, int j) {
			this.i = i;
			this.j = j;
		}
	}
}
