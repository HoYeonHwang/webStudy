package hw0810;

public class ProductMgr {
	TV[] tv = new TV[100];
	Refrigerator[] rf = new Refrigerator[100];
	private int index;

	public void add(TV t, Refrigerator r) {
		tv[index] = t;
		rf[index] = r;
		index++;
	}

	public void list() {
		for (int i = 0; i < index; i++) {
			System.out.println(tv[i].toString());
			System.out.println(rf[i].toString());
		}
	}

	public void list(int select, int num) {
		if (select == 1) {
			for (int i = 0; i < index; i++) {
				if (tv[i] != null && tv[i].getIspn() == num) {
					System.out.println(tv[i].toString());
				}
			}
		} else if (select == 2) {
			for (int i = 0; i < index; i++) {
				if (rf[i] != null && rf[i].getIspn() == num) {
					System.out.println(rf[i].toString());
				}
			}
		}
	}

	public void list(int select, String name) {
		if (select == 1) {
			for (int i = 0; i < index; i++) {
				if (tv[i] != null && tv[i].getTitle().equals(name)) {
					System.out.println(tv[i].toString());
				}
			}
		} else if (select == 2) {
			for (int i = 0; i < index; i++) {
				if (rf[i] != null && rf[i].getTitle().equals(name)) {
					System.out.println(rf[i].toString());
				}
			}
		}
	}

	public void listtv() {
		for (int i = 0; i < index; i++) {
			System.out.println(tv[i].toString());
		}
	}

	public void listrf() {
		for (int i = 0; i < index; i++) {
			System.out.println(rf[i].toString());
		}
	}

	public void delete(int select, int num) {
		if (select == 1) {
			for (int i = 0; i < index; i++) {
				if (tv[i] != null && tv[i].getIspn() == num) {
					for (int j = i + 1; j < index; j++) {
						tv[i] = tv[j];
					}
					index--;
				}
			}
		} else if (select == 2) {
			for (int i = 0; i < index; i++) {
				if (rf[i] != null && rf[i].getIspn() == num) {
					for (int j = i + 1; j < index; j++) {
						rf[i] = rf[j];
					}
					index--;
				}
			}
		}
	}
		public int priceList() {
			int sum=0;
			for(int i=0;i<index;i++) {
				if(tv[i]!=null ) {
					sum = sum+tv[i].getPrice();
				}
				if(rf[i]!=null) {
					sum=sum+rf[i].getPrice();
				}
			}
			return sum;
		}
}
