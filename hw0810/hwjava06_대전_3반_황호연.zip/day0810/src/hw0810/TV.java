package hw0810;

public class TV extends Product{
	private int size;

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	@Override
	public String toString() {
		return super.toString() +"TV [size=" + size + "]";
	}

	public TV(int ispn, String title, int price, int remain, int size) {
		super(ispn, title, price, remain);
		this.size = size;
	}
	public TV() {
		
	}
	
}
