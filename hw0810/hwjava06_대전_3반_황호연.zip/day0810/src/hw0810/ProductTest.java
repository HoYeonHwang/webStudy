package hw0810;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		ProductMgr productmgr = new ProductMgr();
		Scanner sc = new Scanner(System.in);
		while (true) {
			int key=0;

			if(key==1) {
				break;
			}
			print();
			int N = sc.nextInt();
			sc.nextLine();
			switch (N) {
			case 1:
				TV tv = new TV();
				System.out.println("TV 제품 번호 >>");
				tv.setIspn(sc.nextInt());
				sc.nextLine();
				System.out.println("TV 제품 명>>");
				tv.setTitle(sc.nextLine());
				System.out.println("TV 가격 정보>>");
				tv.setPrice(sc.nextInt());
				System.out.println("TV 재고 수량>>");
				tv.setRemain(sc.nextInt());
				System.out.println("TV 사이즈>>");
				tv.setSize(sc.nextInt());
				sc.nextLine();
				Refrigerator rf = new Refrigerator();
				System.out.println("RF 제품 번호>>");
				rf.setIspn(sc.nextInt());
				sc.nextLine();
				System.out.println("RF 제품 명>>");
				rf.setTitle(sc.nextLine());
				System.out.println("RF 가격 정보>>");
				rf.setPrice(sc.nextInt());
				System.out.println("RF 재고 수량>>");
				rf.setRemain(sc.nextInt());
				System.out.println("RF 크기>>");
				rf.setBig(sc.nextInt());
				sc.nextLine();
				productmgr.add(tv,rf);
				
				break;
			case 2:
				productmgr.list();
				break;
			case 3:
				int select,num;
				System.out.println("TV검색 1. RF검색 2.");
				select=sc.nextInt();
				System.out.println("상품번호로 상품 검색");
				num=sc.nextInt();
				sc.nextLine();
				productmgr.list(select,num);
				break;
			case 4:
				String name;
				System.out.println("TV검색 1. RF검색 2.");
				select=sc.nextInt();
				sc.nextLine();
				System.out.println("상품명으로 상품 검색");
				name=sc.nextLine();
				productmgr.list(select,name);
				break;
			case 5:
				productmgr.listtv();
				break;
			case 6:
				productmgr.listrf();
				break;
			case 7:
				System.out.println("TV삭제 1. RF삭제 2.");
				select=sc.nextInt();
				System.out.println("상품번호로 상품 삭제");
				num=sc.nextInt();
				sc.nextLine();
				productmgr.delete(select,num);
				break;
			case 8:
				int sum=0;
				sum =productmgr.priceList();
				System.out.println(sum);
				break;
			case 0:
				key=1;
				break;
			default:
				break;
			}
		}
	}

	public static void print() {
		System.out.println("****************");
		System.out.println("<< ABC 디지털 대리점 >>");
		System.out.println("1.상품 정보 저장");
		System.out.println("2.상품 전체 검색");
		System.out.println("3.상품 번호 검색");
		System.out.println("4.상품 명 저장");
		System.out.println("5.TV 정보만 검색");
		System.out.println("6.냉장고 검색");
		System.out.println("7.상품 번호 삭제");
		System.out.println("8.전체 재고 금액");
		System.out.println("0.종료");
		System.out.println("****************");

	}
}
