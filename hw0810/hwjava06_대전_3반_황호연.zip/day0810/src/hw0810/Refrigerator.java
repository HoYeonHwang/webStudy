package hw0810;

public class Refrigerator extends Product {
	private int big;

	public int getBig() {
		return big;
	}

	public void setBig(int big) {
		this.big = big;
	}

	public Refrigerator(int ispn, String title, int price, int remain, int big) {
		super(ispn, title, price, remain);
		this.big = big;
	}

	@Override
	public String toString() {
		return super.toString() +"Refrigerator [big=" + big + "]";
	}
	public Refrigerator() {
		
	}
}
