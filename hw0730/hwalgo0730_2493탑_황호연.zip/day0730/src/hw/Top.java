package hw;

import java.util.Scanner;

public class Top {
	private static int N, top;
	static int[] input, stack, output;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		input = new int[N];
		stack = new int[N];
		output = new int[N];
		for (int i = 0; i < N; i++) {
			input[i] = sc.nextInt();
			push(input[i]);
		}
		for (int i = 0; i < N; i++) {
			int cnt = 0;
			int temp = pop();
			for (int k = top-1; k >= 0; k--) {
				if (stack[k] > temp) {
					output[top] = k+1;
					break;
				} else {
					output[top] = 0;
				}
			}
		}
		for (int i = 0; i < N; i++) {
			System.out.print(output[i]+" ");
		}
	}

	private static void push(int add) {
		stack[top] = add;
		top++;
	}

	private static int pop() {
		return stack[--top];
	}

}
