package 백준_2477_참외밭;

public class Main {

}
