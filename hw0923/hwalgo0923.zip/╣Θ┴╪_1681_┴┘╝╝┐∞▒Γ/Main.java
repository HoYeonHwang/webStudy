package 백준_1681_줄세우기;

import java.util.Scanner;

public class Main {
	static int N;
	static String L;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N=sc.nextInt();
		L=sc.next();
		int cnt=0;
		int i=1;
		while(true) {
			String temp = Integer.toString(i);
			if(!temp.contains(L)) {
				cnt++;
			}
			if(cnt==N) {
				break;
			}else {
				i++;
			}
		}
		System.out.println(i);
	}
}
