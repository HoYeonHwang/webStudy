package 백준_2563_색종이;

import java.util.Scanner;

public class Main {
	static boolean map[][];
	static int N,Answer;
	static int[] x;
	static int[] y;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		map = new boolean[100][100];
		N = sc.nextInt();
		x = new int[N];
		y = new int[N];
		for(int i=0;i<N;i++) {
			x[i]=sc.nextInt();
			y[i]=sc.nextInt();
		}
		
		for(int k=0;k<N;k++) {
			for(int i=0;i<10;i++) {
				for(int j=0;j<10;j++) {
					map[x[k]+i][y[k]+j]=true;
				}
			}
		}
		
		for(int i=0;i<100;i++) {
			for(int j=0;j<100;j++) {
				if(map[i][j]) {
					Answer++;
				}
			}
		}
		System.out.println(Answer);
	}
}
