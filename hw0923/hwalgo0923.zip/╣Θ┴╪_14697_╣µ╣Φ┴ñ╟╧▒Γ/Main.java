package 백준_14697_방배정하기;

public class Main {

}
