package 백준_2578_빙고;

import java.util.Scanner;

public class Main {
	static int map[][];
	static int number[];
	static int Answer;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		map = new int[5][5];
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				map[i][j] = sc.nextInt();
			}
		}
		number = new int[26];
		for (int i = 0; i < 25; i++) {
			number[i] = sc.nextInt();
		}
		int k = 0;
		while (true) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {
					if (map[i][j] == number[k]) {
						map[i][j] = 0;
					}
				}
			}
			if(Check()>=3) {
				Answer++;
				break;
			}else {
				Answer++;
				k++;
			}
		}
		System.out.println(Answer);
	}
	public static int Check() {
		int bingo=0;
		for(int i=0;i<5;i++) {
			int cnt=0;
			for(int j=0;j<5;j++) {
				if(map[i][j]==0) {
					cnt++;
				}
			}
			if(cnt==5) {
				bingo++;
			}
		}
		for(int j=0;j<5;j++) {
			int cnt=0;
			for(int i=0;i<5;i++) {
				if(map[i][j]==0) {
					cnt++;
				}
			}
			if(cnt==5) {
				bingo++;
			}
		}
		int cnt=0;
		for(int i=0;i<5;i++) {
			if(map[i][i]==0) {
				cnt++;
			}
			if(cnt==5) {
				bingo++;
			}
		}
		cnt=0;
		for(int i=0;i<5;i++) {
			if(map[i][4-i]==0) {
				cnt++;
			}
			if(cnt==5) {
				bingo++;
			}
		}
		return bingo;
	}
}
