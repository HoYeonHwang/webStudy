package 백준_2564_경비원;

import java.util.Scanner;

public class Main {
	static int R, C, N, Answer;
	static int[] x, y, l;
	static int dx, dy, dl;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		R = sc.nextInt();
		C = sc.nextInt();
		N = sc.nextInt();
		x = new int[N];
		y = new int[N];
		l = new int[N];

		int a = 0, b = 0;
		for (int i = 0; i <= N; i++) {
			a = 0;
			b = 0;
			a = sc.nextInt();
			b = sc.nextInt();
			if (i != N) {
				l[i] = a;
				if (a == 1) {
					x[i] = b;
					y[i] = 0;
				} else if (a == 2) {
					x[i] = b;
					y[i] = C;
				} else if (a == 3) {
					x[i] = 0;
					y[i] = b;
				} else if (a == 4) {
					x[i] = R;
					y[i] = b;
				}
			} else if (i == N) {
				dl = a;
				if (a == 1) {
					dx = b;
					dy = 0;
				} else if (a == 2) {
					dx = b;
					dy = C;
				} else if (a == 3) {
					dx = 0;
					dy = b;
				} else if (a == 4) {
					dx = R;
					dy = b;
				}
			}
		}

		int[] temp = new int[N];
		for (int i = 0; i < N; i++) {
			if (l[i] == dl) {
				if (dl == 1 || dl == 2) {
					temp[i] = Math.abs(x[i] - dx);
				} else {
					temp[i] = Math.abs(y[i] - dy);
				}
			} else {
				int val1 = 0, val2 = 0;
				if ((l[i] == 1 && dl == 2) || (l[i] == 2 && dl == 1)) {
					val1 = x[i] + y[i] + dx + dy;
					val2 = (R - dx) + dy + (R - x[i]) + y[i];
					temp[i] = Math.min(val1, val2);
				} else if ((l[i] == 3 && dl == 4) || (l[i] == 4 && dl == 3)) {
					val1 = x[i] + y[i] + dx + dy;
					val2 = dx + (C - dy) + x[i] + (C - y[i]);
					temp[i] = Math.min(val1, val2);
				} else {
					temp[i] = Math.abs(x[i] - dx) + Math.abs(y[i] - dy);
				}
			}
		}
		for (int i = 0; i < N; i++) {
			Answer = Answer + temp[i];
		}
		System.out.println(Answer);
	}
}
