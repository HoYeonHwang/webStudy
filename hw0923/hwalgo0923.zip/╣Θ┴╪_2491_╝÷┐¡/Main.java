package 백준_2491_수열;

import java.util.Scanner;

public class Main {
	static int N, Answer;
	static int[] numbers;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		numbers = new int[N];
		for (int i = 0; i < N; i++) {
			numbers[i] = sc.nextInt();
		}
		Answer = Math.max(rCheck(0), Check(0));
		System.out.println(Answer);
	}

	public static int Check(int i) {
		int ans = 0;
		int a = 0;
		while (i + 1 < N) {
			if (numbers[i] <= numbers[i + 1]) {
				a++;
			} else {
				ans = Math.max(ans, a);
				a = 0;
			}
			i++;
		}
		ans = Math.max(ans, a);
		return ans+1;
	}

	public static int rCheck(int i) {
		int ans = 0;
		int a = 0;
		while (i + 1 < N) {
			if (numbers[i] >= numbers[i + 1]) {
				a++;
			} else {
				ans = Math.max(ans, a);
				a = 0;
			}
			i++;
		}
		ans = Math.max(ans, a);
		return ans+1;
	}
}