package day0917_WS;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MainServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("ID");
		String pw = request.getParameter("PW");
		System.out.println(id + " / " + pw);
		if (id.equals("ssafy") && pw.equals("1111")) {
			response.sendRedirect("WS_Result.html");
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("/WS_Login.html");
			rd.forward(request, response);
		}
	}

}
