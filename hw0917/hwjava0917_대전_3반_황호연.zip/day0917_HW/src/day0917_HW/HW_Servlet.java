package day0917_HW;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HW_servlet
 */
@WebServlet("/HW_Servlet")
public class HW_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HW_Servlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String title = request.getParameter("title");
		String price = request.getParameter("price");
		String content = request.getParameter("content");
		
		System.out.println("상품 명 : "+title);
		System.out.println("상품 가격 : "+price);
		System.out.println("상품 설명 : "+content);
		RequestDispatcher rd = request.getRequestDispatcher("/HW_main.html");
		rd.forward(request, response);
	}
	

}
