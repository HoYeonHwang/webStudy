package Stream_01;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

public class Stream_01 {
public static void main(String[] args) {
		
		{
			String[] strArray = {"A", "B", "C"};
			
			Stream<String> stream = Stream.of(strArray);
			print(stream);
		}
		
		{
			List<String> list = Arrays.asList("D", "E", "F");
			
			Stream<String> stream = list.stream();
			print(stream);
		}
		
		{
			Stream<Integer> stream = Stream.generate(() -> { return new Random().nextInt(10); }).limit(5);
			print(stream);
		}
		
		{
			Stream<Integer> stream = Stream.iterate(1, n -> n + 2).limit(10);
			print(stream);
		}
	}

	public static void print(Stream<?> stream) {
		stream.forEach( a -> System.out.print(a + " "));
		System.out.println();
	}
}

