package Lambda_01;

@FunctionalInterface
public interface MyFuncIF {
	int add( int i, int j );
}

