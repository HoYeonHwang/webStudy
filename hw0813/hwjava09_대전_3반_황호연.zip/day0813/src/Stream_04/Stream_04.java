package Stream_04;

import java.util.Arrays;
import java.util.stream.Stream;

public class Stream_04 {
	public static void main(String[] args) {

		{
			String[] strArray = { "A", "B", "C", "B", "D", "C" };
			Stream<String> stream = Arrays.stream(strArray).distinct();

			print(stream);
		}

		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray).filter((n) -> {
				return n > 2;
			});

			print(stream);
		}

		{
			Integer[] intArray = { 11, 12, 13, 14, 15 };
			Stream<Integer> stream = Arrays.stream(intArray).limit(3);

			print(stream);
		}

		{
			Integer[] intArray = { 1, 2, 3, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray).limit(2).skip(3);

			print(stream);
		}

		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray).sorted();

			print(stream);
		}

		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray).sorted((n1, n2) -> {
				return n2 - n1;
			});

			print(stream);
		}

	}

	public static void print(Stream<?> stream) {
		stream.forEach(a -> System.out.print(a + " "));
		System.out.println();
	}
}
