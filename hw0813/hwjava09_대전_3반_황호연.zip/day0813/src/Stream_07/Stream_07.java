package Stream_07;

import java.util.Arrays;
import java.util.stream.Stream;

public class Stream_07 {
	public static void main(String[] args) {
		String[] strArray = { "A", "B", "C", "B", "D", "C" };
		Stream<String> stream = Arrays.stream(strArray);
		Stream<String> stream2 = stream.map(c -> c + 1);
		stream2 = stream2.distinct();
		print(stream2);
	}

	public static void print(Stream<?> stream) {
		stream.forEach(a -> System.out.print(a + " "));
		System.out.println();
	}
}
