package com.ssafy.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.ProductDAO;
import com.ssafy.model.ProductDTO;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		System.out.println("action : "+action);
	
		if (action != null && action.equals("product")) {
			// 상품 등록
			int number = Integer.parseInt(request.getParameter("number"));
			String title = request.getParameter("title");
			String price = request.getParameter("price");
			String comment = request.getParameter("comment");
			HttpSession session = request.getSession();
			ProductDTO product = new ProductDTO(number, title, price, comment);
			
			// DB에 상품 저장
			ProductDAO dao = ProductDAO.getInstance();
			dao.insertProduct(product);
			request.setAttribute("insertedProduct", product);

			RequestDispatcher dispatcher = request.getRequestDispatcher("Result.jsp");
			dispatcher.forward(request, response);
		} else if (action != null && action.equals("ProductList")) {
			ProductDAO dao = ProductDAO.getInstance();
			List<ProductDTO> productList = dao.searchAll();

			request.setAttribute("ProductList", productList);

			RequestDispatcher dispatcher = request.getRequestDispatcher("ProductList.jsp");
			dispatcher.forward(request, response);
		}else if (action != null && action.equals("ProductLast")) {
			ProductDAO dao = ProductDAO.getInstance();
			ProductDTO product = dao.searchLast();

			request.setAttribute("Product", product);

			RequestDispatcher dispatcher = request.getRequestDispatcher("ProductLast.jsp");
			dispatcher.forward(request, response);
		}else if(action !=null &&action.equals("price")) {
			int price = Integer.parseInt(request.getParameter("price"));
			ProductDAO dao = ProductDAO.getInstance();
			List<ProductDTO> priceList = dao.searchPrice(price);
			request.setAttribute("PriceValue", priceList);
			RequestDispatcher dispatcher = request.getRequestDispatcher("PriceList.jsp");
			dispatcher.forward(request, response);
		}else if(action !=null &&action.equals("title")) {
			String title = request.getParameter("title");
			ProductDAO dao = ProductDAO.getInstance();
			List<ProductDTO> titleList = dao.searchTitle(title);
			for(ProductDTO p : titleList) {
				System.out.println(p.getProduct_title());
			}
			request.setAttribute("TitleValue", titleList);
			RequestDispatcher dispatcher = request.getRequestDispatcher("TitleList.jsp");
			dispatcher.forward(request, response);
		}
	}
}
