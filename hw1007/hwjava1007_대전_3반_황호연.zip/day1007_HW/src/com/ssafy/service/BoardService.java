package com.ssafy.service;

public class BoardService {
	
}
