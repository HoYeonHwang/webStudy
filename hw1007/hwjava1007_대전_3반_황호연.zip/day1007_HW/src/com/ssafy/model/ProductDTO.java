package com.ssafy.model;

public class ProductDTO {
	int Product_number;
	String Product_title;
	String Product_price;
	String Product_comment;
	public int getProduct_number() {
		return Product_number;
	}
	public void setProduct_number(int product_number) {
		Product_number = product_number;
	}
	public String getProduct_title() {
		return Product_title;
	}
	public void setProduct_title(String product_title) {
		Product_title = product_title;
	}
	public String getProduct_price() {
		return Product_price;
	}
	public void setProduct_price(String product_price) {
		Product_price = product_price;
	}
	public String getProduct_comment() {
		return Product_comment;
	}
	public void setProduct_comment(String product_comment) {
		Product_comment = product_comment;
	}
	public ProductDTO(int product_number, String product_title, String product_price, String product_comment) {
		Product_number = product_number;
		Product_title = product_title;
		Product_price = product_price;
		Product_comment = product_comment;
	}
	public ProductDTO() {
	}
	@Override
	public String toString() {
		return "ProductDTO [Product_number=" + Product_number + ", Product_title=" + Product_title + ", Product_price="
				+ Product_price + ", Product_comment=" + Product_comment + "]";
	}
	
}
