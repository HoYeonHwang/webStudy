package day0811_ws01;

import java.util.ArrayList;

import day0811_hw.Product;

public class BookMgrList implements IBookMgr{
	// BookMgr의 싱글톤
	private static BookMgrList instance = new BookMgrList(); 
	private BookMgrList() {}
	public static BookMgrList getInstance() {
		return instance;
	}
///////////////////////////////////////////////////////////////
	private ArrayList<Book> books = new ArrayList<>();
///////////////////////////////////////////////////////////////	
	@Override
	public void add(Book b) {
		books.add(b);
	}
	@Override
	public Book[] list() {
		return (Book[])books.toArray();
	}
	@Override
	public Book list(String isbn) {
		for(Book b: books) {
			if(b.equals(isbn))
				return b;
		}
		return null;
	}
	@Override
	public Book[] listName(String title) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b: books) {
			if(b.getTitle().contains(title))
				temp.add(b);
		}
		return (Book[])temp.toArray();
	}
	@Override
	public Book[] listOneSide(boolean flag) { // true=Book, false=Magazine
		ArrayList<Book> temp = new ArrayList<>();
		for (Book b: books) {
			if (flag == false && b instanceof Magazine) {
				// 현재 검색 모드가 Magazine 검색이고 i번 객체가 Magazine인 경우 
				temp.add(b);
			}else if (flag == true && b instanceof Book) {
				// 현재 검색 모드가 Book이고 i번 객체가 Book인 경우
				temp.add(b);
			}
		}
		return (Book[])temp.toArray();
	}
	@Override
	public Book[] listPublisher(String publisher) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b: books) {
			if(b.getPublisher().contains(publisher))
				temp.add(b);
		}
		return (Book[])temp.toArray();
	}
	@Override
	public Book[] priceList(int price) {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book b: books) {
			if(b.getPrice()<price)
				temp.add(b);
		}
		return (Book[])temp.toArray();
	}
	@Override
	public int totalPrice() {
		if (books.size() == 0) {
			System.out.println("상품이 없습니다");
			return 0;
		}
		int sum = 0;
		for (int i = 0; i < books.size(); i++) {
			sum+=(books.get(i).getPrice());
		}
		return sum;
	}
	@Override
	public double averPrice() {
		if (books.size() == 0) {
			System.out.println("상품이 없습니다");
			return 0;
		}
		int sum = 0;
		for (int i = 0; i < books.size(); i++) {
			sum+=(books.get(i).getPrice());
		}
		return sum/books.size();
	}
	@Override
	public Book[] listCurrentYear() {
		ArrayList<Book> temp = new ArrayList<>();
		for(Book p : books) {
			if(((Magazine)p).getYear()==2020) {
				temp.add(p);
			}
		}
		return temp.toArray(new Book[temp.size()]);
	}
	
}