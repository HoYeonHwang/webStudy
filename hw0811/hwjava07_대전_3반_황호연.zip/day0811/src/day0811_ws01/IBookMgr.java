package day0811_ws01;

public interface IBookMgr {
	public void add(Book b);
	public Book[] list() ;
	public Book list(String isbn);
	public Book[] listName(String title) ;
	public Book[] listOneSide(boolean flag) ;
	public Book[] listPublisher(String publisher);
	public Book[] priceList(int price);
	public Book[] listCurrentYear();
	public int totalPrice();
	public double averPrice();
}
