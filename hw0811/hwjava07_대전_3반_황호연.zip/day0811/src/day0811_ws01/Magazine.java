package day0811_ws01;

public class Magazine extends Book {// Book이라는 클래스가 현재 메거진 클래스와 같은 패키지 또는 다른 패키지.
	private int year, month;
	//Magazine 정보를 저장할 클래스를 작성(상속 활용) protected를 사용하면 extends를 통한 외부 패키지에서 사용이 가능.
	protected Magazine(String isbn, String title, String author, String publisher, String desc, int price, int year,
			int month) {
		super(isbn, title, author, publisher, desc ,price);
		this.year = year;
		this.month = month;
	}
	//toString(Book에서의 toString을 이어서.)
	@Override
	public String toString() {
		return super.toString()+ ", year=" + year + ", month=" + month;
	}
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public Magazine() {//기본 생성자

	}
}
