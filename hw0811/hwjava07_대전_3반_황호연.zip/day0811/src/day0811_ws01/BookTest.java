package day0811_ws01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BookTest {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		IBookMgr bmgr = BookMgrArray.getInstance();
		// 이 부분에서 배열버전 리스트 버전 동작은 동일해야함. (물론 배열은 최대 갯수의 제한은 있음.)
//		IBookMgr bmgr = BookMgrList.getInstance();
		String isbn = "";
		String title = "";
		String publisher = "";
		int price = 0;
		while (true) {
			print();
			int select = Integer.parseInt(br.readLine());

			if (select == 0) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}

			switch (select) {
			case 1: // 데이터 입력 기능 (String isbn, String title, String author, String publisher, String
					// desc, int price)
				String[] input = new String[8];
				input = br.readLine().split(" ");
				if (input.length == 6)// input이 6개 이하. = Book
				{
					bmgr.add(new Book(input[0], input[1], input[2], input[3], input[4], Integer.parseInt(input[5])));
				} else {// input이 6개 초과 ~8개 = Magazine
					bmgr.add(new Magazine(input[0], input[1], input[2], input[3], input[4], Integer.parseInt(input[5]),
							Integer.parseInt(input[6]), Integer.parseInt(input[7])));
				}
				break;
			case 2: // /** 저장된 상품들을 볼 수 있는 기능 */
				boolean empty = true;
				Book[] temp = bmgr.list();
				for (Book p : temp) {
					if (p == null) {
						break;
					}
					System.out.println(p);
					empty = false;
				}
				if (empty == true)
					System.out.println("찾는 상품이 없습니다");
				System.out.println("=============================");
				break;
			case 3: // /** Isbn 으로 정보를 검색하는 기능 */

				System.out.println("상품 번호>>");
				isbn = br.readLine();
				Book b = bmgr.list(isbn);
				if (b == null) {
					System.err.println("찾는 상품이 없습니다");
				} else
					System.out.println(b);
				break;
			case 4: // Title로 정보를 검색하는 기능( 파라메터로 주어진 제목을 포함하는 모든 정보)
				System.out.println("상품 명>>");
				title = br.readLine();
				temp = bmgr.listName(title);
				if (temp[0] == null) {
					System.err.println("찾는 상품이 없습니다");
				} else {
					for (Book x : temp) {
						if (x == null)
							break;
						System.out.println(x);
					}
				}
				break;
			case 5: // Book만
				System.out.println("Book정보만 검색>>");
				temp = bmgr.listOneSide(true);
				if (temp[0] == null) {
					System.err.println("찾는 상품이 없습니다");
				} else {
					for (Book x : temp) {
						if (x == null)
							break;
						System.out.println(x);
					}
				}
				break;
			case 6: // Magazine만
				System.out.println("Magazine 정보만 검색>>");
				temp = bmgr.listOneSide(false);
				if (temp[0] == null) {
					System.err.println("찾는 상품이 없습니다");
				} else {
					for (Book x : temp) {
						if (x == null) {
							break;
						}
						System.out.println(x);
					}
				}
				break;
			case 7:
				temp = bmgr.listCurrentYear();
				if (temp[0] == null) {
					System.err.println("올해 발간된 잡지는 없습니다.");
				} else {
					for (Book x : temp) {
						if (x == null) {
							break;
						}
						System.out.println(x);
					}
				}

				break;
			case 8: // 출판사로 검색하는 기능
				System.out.println("출판사 명>>");
				publisher = br.readLine();
				temp = bmgr.listPublisher(publisher);
				if (temp[0] == null) {
					System.err.println("찾는 상품이 없습니다");
				} else {
					for (Book x : temp) {
						if (x == null)
							break;
						System.out.println(x);
					}
				}
				break;
			case 9: // 가격으로 검색 기능 (파라메터로 주어진 가격보다 낮은 도서 정보 검색)
				System.out.println("특정 가격>>");
				price = Integer.parseInt(br.readLine());
				temp = bmgr.priceList(price);
				if (temp[0] == null) {
					System.err.println("찾는 상품이 없습니다");
				} else {
					for (Book x : temp) {
						if (x == null)
							break;
						System.out.println(x);
					}
				}
				break;
			case 10: // 전체 재고 상품 금액
				System.out.println("전체 재고 상품 금액 합 > " + bmgr.totalPrice());
				break;
			case 11: // 전체 재고 상품 금액
				System.out.println("전체 재고 상품 금액 평균 > " + bmgr.averPrice());
			case 0:
				System.out.println("=========종료========");
				break;
			}
		}

	}

	static void print() {
		System.out.println();
		System.out.println("<< Book 관리 프로그램>>>");
		System.out.println("1. 데이터 입력 기능");
		System.out.println("2. 데이터 전체 검색 기능 ");
		System.out.println("3. Isbn 으로 정보를 검색하는 기능 ");
		System.out.println("4. Title로 정보를 검색하는 기능( 파라메터로 주어진 제목을 포함하는 모든 정보)");
		System.out.println("5. Book만 검색하는 기능");
		System.out.println("6. Magazine만 검색하는 기능");
		System.out.println("7. Magazine 중 올해 잡지만 검색하는 기능");
		System.out.println("8. 출판사로 검색하는 기능 ");
		System.out.println("9. 가격으로 검색 기능 (파라메터로 주어진 가격보다 낮은 도서 정보 검색)");
		System.out.println("10. 저장된 모든 도서의 금액 합계를 구하는 기능");
		System.out.println("11.저장된 모든 도서의 금액 평균을 구하는 기능");
		System.out.println("0. 종료 ");
		System.out.print("원하는 번호를 선택하세요 : ");
	}

}
/*
 * // 데이터 입력 기능 (String isbn, String title, String author, String publisher,
 * String // desc, int price) book isbn1 title1 author1 publisher1 desc1 100
 * Maga isbn2 title2 author2 publisher2 desc2 200 2 3 book isbn3 title3 author3
 * publisher3 desc3 300 Maga isbn4 title4 author4 publisher4 desc4 400 4 6
 * 
 * 
 * 
 * 
 * 
 * 
 */