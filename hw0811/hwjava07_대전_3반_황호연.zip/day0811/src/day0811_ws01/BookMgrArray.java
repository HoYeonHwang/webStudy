package day0811_ws01;

import day0811_hw.TV;

public class BookMgrArray implements IBookMgr {
	// BookMgr의 싱글톤
	private static BookMgrArray instance = new BookMgrArray();

	private BookMgrArray() {
	}

	public static BookMgrArray getInstance() {
		return instance;
	}

	///////////////////////////////////////////////////////
	private Book[] book = new Book[30];
	private int index = 0;

	////////////////////////////////////////////////////////
	/** 상품을 저장하는 기능 */
	public void add(Book b) {
		book[index++] = b;
	}

	public Book[] list() {
		return book;
	}

	public Book list(String isbn) {
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				return null;
			if (book[i].getIsbn().equals(isbn)) {
				return book[i];
			}
		}
		return null;
	}

	public Book[] listName(String keyword) {
		int count = 0;
		// 일단 검색 결과가 몇개인지 먼저 갯수를 세고 나서
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getTitle().contains(keyword)) {
				count += 1;
			}
		}
		// 검색 결과가 담길 배열 생성해서 넣기
		Book[] temp = new Book[count];
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getTitle().contains(keyword)) {
				temp[idx++] = book[i];
			}
		}
		return temp;
	}

	public Book[] listOneSide(boolean flag) { // true = book , false = Magazine
		int count = 0;
		// 일단 Book 또는 Magazine이 몇개인지 먼저 갯수를 세고 나서
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (flag == false && book[i] instanceof Magazine) {
				// 현재 검색 모드가 Magazine 검색이고 i번 객체가 Magazine인 경우
				count += 1;
			} else if (flag == true && book[i] instanceof Book) {
				// 현재 검색 모드가 Book이고 i번 객체가 Book인 경우
				count += 1;
			}
		}

		// 해당 하는 Book 또는 Magazine만 배열에 담아서 리턴
		Book[] temp = new Book[count];
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (flag == false && book[i] instanceof Magazine) {
				temp[idx++] = book[i];
			} else if (flag == true && book[i] instanceof Book) {
				temp[idx++] = book[i];
			}
		}
		return temp;
	}

	public Book[] listPublisher(String publisher) {
		int count = 0;
		// 사이즈 먼저 측정
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getPublisher().contains(publisher)) {
				count += 1;
			}
		}
		// 검색 결과 담기
		Book[] temp = new Book[count];
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getPublisher().contains(publisher)) {
				temp[idx++] = book[i];
			}
		}
		return temp;
	}

	public Book[] priceList(int price) {
		int count = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getPrice() < price) {
				count += 1;
			}
		}

		Book[] temp = new Book[30];
		int idx = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] == null)
				break;
			if (book[i].getPrice() < price) {
				temp[idx++] = book[i];
			}
		}
		return temp;
	}

	public Book[] listCurrentYear() {
		Book[] temp = new Book[30];
		int idx = 0;
		if (index == 0) {
			System.out.println("상품이 없습니다");
		}
		int year = 0;
		for (int i = 0; i < index; i++) {
			if (book[i] instanceof Magazine&&((Magazine) book[i]).getYear()==2020) {
				temp[idx++]=book[i];
			}
		}
		return temp;
	}

	public int totalPrice() {
		if (index == 0) {
			System.out.println("상품이 없습니다");
			return 0;
		}
		int sum = 0;
		for (int i = 0; i < index; i++) {
			sum += (book[i].getPrice());
		}
		return sum;
	}

	public double averPrice() {
		if (index == 0) {
			System.out.println("상품이 없습니다");
			return 0;
		}
		int sum = 0;
		for (int i = 0; i < index; i++) {
			sum += (book[i].getPrice());
		}
		return sum / index;
	}
}
