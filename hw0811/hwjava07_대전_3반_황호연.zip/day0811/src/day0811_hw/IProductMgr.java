package day0811_hw;

public interface IProductMgr {
//	private int ispn;
//	private String title;
//	private int price;
//	private int remain;

	public void add(Product p); // 상품정보를 저장

	public Product[] list(); // 상품정보 전체 검색

	public Product[] list(int price); // 상품번호 상품검색

	public Product[] list(String title); // 상품명 상품 검색

	public Product[] listOneTV(); // TV정보만 검색

	public Product[] listOneRF(); // RF정보만 검색

	public Product[] pickOnRF(); // 400L 이상의 냉장고

	public Product[] pickOnTV(); // 50inch 이상의 TV

	public Product[] recall(int ispn,int price); // 번호와 가격을 입력받아 수정

	public Product[] delete(int ispn);
	
	public int AllPrice();

}
