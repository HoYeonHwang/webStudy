package day0811_hw;

import java.util.ArrayList;

public class ProductMgr implements IProductMgr{
	private static ProductMgr instance = new ProductMgr();
	private ProductMgr() {}
	public static ProductMgr getInstance() {
		return instance;
	}
	
	private ArrayList<Product> product = new ArrayList<Product>();
	
	@Override
	public void add(Product p) {
		product.add(p);
	}
	@Override
	public Product[] list() {
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public Product[] list(int ispn) {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p.getIspn()==ispn) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] list(String title) {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p.getTitle().contains(title)) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] listOneTV() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof TV) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] listOneRF() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof Refrigerator) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] pickOnRF() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof Refrigerator&&((Refrigerator) p).getBig()>=400) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] pickOnTV() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof TV&&((TV) p).getSize()>=50) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] recall(int ispn, int price) {
		for(Product p : product) {
			if(p.getIspn()==ispn) {
				p.setPrice(price);
			}
		}
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public Product[] delete(int ispn) {
		for(int i=0;i<product.size();i++) {
			if(product.get(i).getIspn()==ispn) {
				product.remove(i);
			}
		}
		
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public int AllPrice() {
		if(product.size() == 0) {
			return 0;
		}
		int sum =0;
		for(int i=0;i<product.size();i++) {
			sum = sum +product.get(i).getPrice();
		}
		return sum;
	}
	

	
}
