package day0811_hw;

public class Refrigerator extends Product {
	private int big; //용량

	public int getBig() {
		return big;
	}

	public void setBig(int big) {
		this.big = big;
	}

	public Refrigerator(int ispn, String title, int price, int remain, int big) {
		super(ispn, title, price, remain);
		this.big = big;
	}

	@Override
	public String toString() {
		return super.toString() +"Refrigerator [big=" + big + "]";
	}
	public Refrigerator() {
		
	}
}
