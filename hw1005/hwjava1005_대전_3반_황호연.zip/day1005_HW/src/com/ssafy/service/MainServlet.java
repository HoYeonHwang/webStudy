package com.ssafy.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.ProductDAO;
import com.ssafy.model.ProductDTO;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		System.out.println("action : "+action);
		// 로그인
		if (action != null && action.equals("login")) {
			String userId = request.getParameter("ID");
			String userPw = request.getParameter("PW");

			response.setContentType("text/html;charset=utf-8");
			if (userId != null && userId.equals("ssafy") && userPw != null && userPw.equals("1111")) {
				request.setAttribute("userName", userId);
				RequestDispatcher dispatcher = request.getRequestDispatcher("LoginSuccess.jsp");

				HttpSession session = request.getSession();
				session.setAttribute("LoginInfo", userId);

				dispatcher.forward(request, response);
			} else {
				request.setAttribute("errMsg", "아이디 또는 패스워드가 다릅니다.");
				RequestDispatcher dispatcher = request.getRequestDispatcher("Error.jsp");
				HttpSession session = request.getSession();
				session.invalidate();
				dispatcher.forward(request, response);
			}
		} else if (action != null && action.equals("product")) {
			// 상품 등록
			System.out.println("상품등록?");
			int number = Integer.parseInt(request.getParameter("number"));
			String title = request.getParameter("title");
			String price = request.getParameter("price");
			String comment = request.getParameter("comment");
			HttpSession session = request.getSession();
			String id = (String)session.getAttribute("LoginInfo");
			ProductDTO product = new ProductDTO(number, title, price, comment);
			
			// DB에 상품 저장
			ProductDAO dao = ProductDAO.getInstance();
			dao.insertProduct(product);
			Cookie[] cookies = request.getCookies();
			Cookie cookie = null;
			for(Cookie c : cookies) {
				if(c.getName().equals(id)) {
					cookie = c;
				}
			}
			if(cookie == null) {
				System.out.println("들어가기전:"+id);
				cookie = new Cookie(id,"userinfo");
				System.out.println(cookie.getName());
			}
			response.addCookie(cookie);
			cookie.setMaxAge(60*60);
			request.setAttribute("insertedProduct", product);

			RequestDispatcher dispatcher = request.getRequestDispatcher("Result.jsp");
			dispatcher.forward(request, response);
		} else if (action != null && action.equals("ProductList")) {
			ProductDAO dao = ProductDAO.getInstance();
			List<ProductDTO> productList = dao.searchAll();

			request.setAttribute("ProductList", productList);

			RequestDispatcher dispatcher = request.getRequestDispatcher("ProductList.jsp");
			dispatcher.forward(request, response);
		}else if (action != null && action.equals("ProductLast")) {
			ProductDAO dao = ProductDAO.getInstance();
			ProductDTO product = dao.searchLast();

			request.setAttribute("Product", product);

			RequestDispatcher dispatcher = request.getRequestDispatcher("ProductLast.jsp");
			dispatcher.forward(request, response);
		}
	}
}
