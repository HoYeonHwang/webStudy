package SWEA5607;

import java.math.BigInteger;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			int N = sc.nextInt();
			int R = sc.nextInt();
			long Answer = 0;
			long[] facto = new long[N+1];
			facto[0]=1;
			for(int i=1;i<N;i++) {
				facto[i]=facto[i-1]*i%R;
			}
			BigInteger P = BigInteger.valueOf(1234567891);
			BigInteger A = BigInteger.valueOf(facto[N]);
			BigInteger B = BigInteger.valueOf(facto[R]).modInverse(P).remainder(P);
			BigInteger C = BigInteger.valueOf(facto[N-R]).modInverse(P).remainder(P);
			System.out.println("#"+test_case+" "+A.multiply(B).multiply(C).remainder(P));
		}
	}
}

