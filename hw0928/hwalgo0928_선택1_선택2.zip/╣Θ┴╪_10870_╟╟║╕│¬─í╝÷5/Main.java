package 백준_10870_피보나치수5;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int N = sc.nextInt();
		int[] memo = new int[21];
		Arrays.fill(memo, 0);
		System.out.println(fibonacci(N-1, memo));
	}
	public static int fibonacci(int n,int[] memo) {
		if(n<=1) {
			return n;
		}else if(memo[n]!=0) {
			return memo[n];
		}else {
			return memo[n]=fibonacci(n-1, memo)+fibonacci(n-2, memo);
		}
	}
}
