package 백준_13301_타일장식물;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int N = sc.nextInt();
		long[] fibo = new long[81];
		fibo[0] = 1;
		fibo[1] = 1;
		fibo[2] = 1;
		for (int i = 2; i <= 81; i++) {
			fibo[2] = fibo[0] + fibo[1];
			fibo[0] = fibo[1];
			fibo[1] = fibo[2];
		}

		System.out.print(2 * (fibo[0] + fibo[1]));
	}
}
