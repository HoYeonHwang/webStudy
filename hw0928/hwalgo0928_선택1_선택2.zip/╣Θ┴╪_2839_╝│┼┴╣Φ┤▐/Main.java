package 백준_2839_설탕배달;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int[] dp = new int[5001];
		Arrays.fill(dp, Integer.MAX_VALUE-1);
		dp[3]=dp[5]=1;
		
		for(int i=6;i<=N;i++) {
			dp[i]=Math.min(dp[i-3],dp[i-5])+1;
		}
		if(dp[N]>=Integer.MAX_VALUE-1) {
			System.out.println(-1);
		}else {
			System.out.println(dp[N]);
		}
	}
}
