package 백준_9625_BABBA;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N =sc.nextInt();
		int[] dp=new int[46];
		System.out.println(Sang(N-1,dp)+" "+Sang(N,dp));
	}
	public static int Sang(int n,int[] dp) {
		if(n<=1) {
			return n;
		}else if(dp[n]!=0) {
			return dp[n];
		}else {
			return dp[n]=Sang(n-1,dp)+Sang(n-2,dp);
		}
	}
}
