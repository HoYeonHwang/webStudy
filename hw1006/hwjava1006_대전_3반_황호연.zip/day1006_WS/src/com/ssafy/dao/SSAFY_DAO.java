package com.ssafy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.SSAFY_DTO;
import com.ssafy.utill.DBUtill;

public class SSAFY_DAO {
	private static SSAFY_DAO instance = new SSAFY_DAO();
	public static SSAFY_DAO getInstance() {
		return instance;
	}
	private SSAFY_DAO() {
	}
	
	public List<SSAFY_DTO> selectAll(){
		String sql="SELECT IDX,COUNTRY,GROUP_NUM,CLASS_NUM,PEOPLE_NUM FROM SSAFY_CLASS ";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<SSAFY_DTO> ssafyList = new ArrayList<SSAFY_DTO>();
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int idx = rs.getInt("IDX");
				String country = rs.getString("COUNTRY");
				int groupNum = rs.getInt("GROUP_NUM");
				int classNum = rs.getInt("CLASS_NUM");
				int peopleNum = rs.getInt("PEOPLE_NUM");
				ssafyList.add(new SSAFY_DTO(idx, country, groupNum, classNum, peopleNum));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtill.close(rs);
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		return ssafyList;
	}
}
