package com.ssafy.model;

public class SSAFY_DTO {
	private int idx;
	private String country; // 지역
	private int groupNum; // 기수
	private int classNum; // 반 
	private int peopleNum; // 인원수
	
	
	public SSAFY_DTO(int idx, String country, int groupNum, int classNum, int peopleNum) {
		this.idx = idx;
		this.country = country;
		this.groupNum = groupNum;
		this.classNum = classNum;
		this.peopleNum = peopleNum;
	}
	public SSAFY_DTO(String country, int groupNum, int classNum, int peopleNum) {
		this.country = country;
		this.groupNum = groupNum;
		this.classNum = classNum;
		this.peopleNum = peopleNum;
	}
	public SSAFY_DTO() {
	}
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getGroupNum() {
		return groupNum;
	}
	public void setGroupNum(int groupNum) {
		this.groupNum = groupNum;
	}
	public int getClassNum() {
		return classNum;
	}
	public void setClassNum(int classNum) {
		this.classNum = classNum;
	}
	public int getPeopleNum() {
		return peopleNum;
	}
	public void setPeopleNum(int peopleNum) {
		this.peopleNum = peopleNum;
	}
	
	@Override
	public String toString() {
		return "SSAFY_DTO [idx=" + idx + ", country=" + country + ", groupNum=" + groupNum + ", classNum=" + classNum
				+ ", peopleNum=" + peopleNum + "]";
	}
	
}
