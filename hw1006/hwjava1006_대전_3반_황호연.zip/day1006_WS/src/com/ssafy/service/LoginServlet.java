package com.ssafy.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dao.MemberDAO;
import com.ssafy.model.MemberDto;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "login.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");

		MemberDAO dao = MemberDAO.getInstance();
		MemberDto dto = dao.selectWithIdAndPw(userid, userpwd);
		if (dto != null) {
			HttpSession session = request.getSession();
			session.setAttribute("loginInfo", dto);

			if (request.getParameter("rememberme") != null) {
				Cookie cookie = new Cookie("rememberme", dto.getUserid());
				cookie.setMaxAge(60 * 60 * 24 * 30);
				response.addCookie(cookie);
			}else {
				Cookie cookie = new Cookie("rememberme", "");
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
		} else {

		}
		String path = "loginResult.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}
}
