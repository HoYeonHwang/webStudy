package com.ssafy.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.dao.SSAFY_DAO;
import com.ssafy.model.SSAFY_DTO;

/**
 * Servlet implementation class SSAFY_Servlet
 */
@WebServlet("/ssafy.do")
public class SSAFY_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SSAFY_DAO dao = SSAFY_DAO.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<SSAFY_DTO> ssafyList = dao.selectAll();
		request.setAttribute("ssafyList", ssafyList);
		System.out.println("안온거니?");
		String view = "ssafyList.jsp";
		RequestDispatcher dispatcher = request.getRequestDispatcher(view);
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
