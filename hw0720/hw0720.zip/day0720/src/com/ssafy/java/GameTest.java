package com.ssafy.java;

import java.util.Scanner;

public class GameTest {
	public static void main(String[] args) {
		String temp;
		int User_WinCount = 0;
		int Com_WinCount = 0;
		int GameCount = 0;
		int num =0;
		Scanner sc = new Scanner(System.in);
		System.out.println("가위바위보 게임을 시작합니다. 아래 보기 중 하나를 고르세요>>");
		System.out.println("1.5판 3승");
		System.out.println("2.3판 2승");
		System.out.println("3.1판 1승");
		int select = sc.nextInt();
		System.out.println("입력하신 숫자는 " + select + "입니다.");
		if (select == 1) {
			GameCount = 3;
		} else if (select == 2) {
			GameCount = 2;
		} else if (select == 3) {
			GameCount = 1;
		}
		
		while (true) {
			System.out.println("User : "+User_WinCount+"  Com :"+Com_WinCount);
			System.out.println("가위바위보를 고르세요");
			String input = sc.next();
			System.out.println("당신이 고른 것 :" + input);

			num = (int) (Math.random() * 3) + 1;
			if (num == 1) {
				temp = "주먹";
			} else if (num == 2) {
				temp = "가위";
			} else {
				temp = "보";
			}
			System.out.println("컴퓨터가 고른것 :" + temp);

			if (input.equals("가위") && temp.equals("보")) {
				System.out.println("이겼습니다!");
				User_WinCount++;
			} else if (input.equals("주먹") && temp.equals("가위")) {
				System.out.println("이겼습니다.");
				User_WinCount++;
			} else if (input.equals("보") && temp.equals("주먹")) {
				System.out.println("이겼습니다.");
				User_WinCount++;
			} else if (input.equals(temp)) {
				System.out.println("비겼습니다!!");
			} else {
				System.out.println("졌습니다.");
				Com_WinCount++;
			}
			if (User_WinCount == GameCount) {
				System.out.println("###유저 승리!!!");
				break;
			} else if (Com_WinCount == GameCount) {
				System.out.println("###컴퓨터 승리!!!");
				break;
			}
		}

	}
}
