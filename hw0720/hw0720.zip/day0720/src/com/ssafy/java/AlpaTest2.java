package com.ssafy.java;

public class AlpaTest2 {
	public static void main(String[] args) {
		String[] alpa = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O" };
		int count = 0;
		for (int i = 4; i >=0; i--) {
			for (int j = 0; j < 5; j++) {
				if (j >= i) {
					System.out.print(alpa[count]);
					count++;
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}
