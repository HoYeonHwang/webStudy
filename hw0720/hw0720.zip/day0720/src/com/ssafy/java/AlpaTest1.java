package com.ssafy.java;

public class AlpaTest1 {
	public static void main(String[] args) {
		String[] alpa = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O"};
		int count = 0;
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(alpa[count]);
				count++;
			}
			System.out.println();
		}
		
	}

}
