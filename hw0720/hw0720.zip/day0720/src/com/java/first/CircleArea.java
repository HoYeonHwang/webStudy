package com.java.first;

import java.util.Scanner;

public class CircleArea {
	public static void main(String[] args) {
		final double fi = 3.14;
		int ban=5;
		System.out.println("반지름이 5CM인 원의 넓이는 "+ban*ban*fi+"입니다.");
	}
}
