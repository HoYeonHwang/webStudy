package day0826_WS05;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class 백준_2206_벽부수고이동하기 {
	static int N, M, Cnt, Answer = Integer.MAX_VALUE;
	static int[][] map;
	static int[][] visited, cnt;
	static boolean C;
	static int[] di = { -1, 0, 1, 0 };
	static int[] dj = { 0, 1, 0, -1 };

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		M = sc.nextInt();
		map = new int[N][M];
		cnt = new int[N][M];
		for (int i = 0; i < N; i++) {
			String st = sc.next();
			String[] s = st.split("");
			for (int j = 0; j < M; j++) {
				map[i][j] = Integer.parseInt(s[j]);
			}
		}
		visited = new int[N][M];
		bfs(0, 0);
		if (Answer == Integer.MAX_VALUE) {
			System.out.println(-1);
		} else {
			System.out.println(Answer + 1);
		}
	}

	public static void bfs(int si, int sj) {
		Queue<Point> queue = new LinkedList<Point>();
		queue.add(new Point(si, sj, 0, 0));
		visited[si][sj] = 1;
		while (!queue.isEmpty()) {
			Point Current = queue.poll();
			if (Current.i == N - 1 && Current.j == M - 1) {
				Answer = cnt[N - 1][M - 1];
				break;
			}
			for (int k = 0; k < 4; k++) {
				int ni = Current.i + di[k];
				int nj = Current.j + dj[k];
				int c = Current.c;
				if (ni >= 0 && nj >= 0 && ni < N && nj < M && map[ni][nj] == 0) {
					if (Current.t == 0) {
						if (visited[ni][nj] == 0||visited[ni][nj] == 2) {
							c++;
							cnt[ni][nj] = c;
							visited[ni][nj] = 1;
							
							queue.add(new Point(ni, nj, c, Current.t));
						} 

					} else if (Current.t == 1) {
						if (visited[ni][nj] == 0) {
							c++;
							cnt[ni][nj] = c;
							visited[ni][nj] = 2;
							queue.add(new Point(ni, nj, c, Current.t));
						} 
					}

				} else if (ni >= 0 && nj >= 0 && ni < N && nj < M && map[ni][nj] == 1) {
					if (Current.t == 0) {
						if (visited[ni][nj] == 0) {
							c++;
							cnt[ni][nj] = c;
							Current.t++;
							visited[ni][nj] = 3;
							queue.add(new Point(ni, nj, c, Current.t));
						}
					}
				}
			}
		}
	}

	static class Point {
		int i, j, c, t;

		Point(int i, int j, int c, int t) {
			this.i = i;
			this.j = j;
			this.c = c;
			this.t = t;
		}
	}
}
