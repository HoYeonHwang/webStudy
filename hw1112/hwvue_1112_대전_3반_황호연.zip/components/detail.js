export default {
  template: ` <div id="app">
    <h2>사원세부사항</h2>
    <table>
      <thead>
        <tr>
          <th scope="col">사원 아이디</th>
          <th scope="col">사원명</th>
          <th scope="col">부서</th>
          <th scope="col">직책</th>
          <th scope="col">연봉</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="e in emps" v-if="no==e.id">
          <th>{{e.id}}</th>
          <td>{{e.name}}</td>
          <td>{{e.dep}}</td>
          <td>{{e.job}}</td>
          <td>{{e.sal}}</td>
        </tr>
      </tbody>
    </table>
    <div>
    <router-link :to="{name:'list'}"> 목록 </router-link>
    <button type="button" @click="remove">삭제</button>
    </div>
  </div>`,
  data() {
    return {
      emps: [],
      no: 0,
    };
  },
  created() {
    this.emps = localStorage.getItem('emps');
    this.emps = JSON.parse(this.emps);
    this.no = this.$route.params.id;
  },
  methods: {
    remove() {
      for (var i = 0; i < this.emps.length; i++) {
        if (this.no == this.emps[i].id) {
          this.emps.splice(i, 1);
          alert('삭제되었습니다.');
          break;
        }
      }
      localStorage.setItem('emps', JSON.stringify(this.emps));
    },
  },
};
