export default {
  template: ` <div id="app">
    <h2>SSAFY HRM ADD EMPLOEE</h2>
    <table>
      <tr>
        <td>이름</td>
        <td>
          <input
            type="text"
            id="name"
            v-model="newEmp.name"
            placeholder="사원명을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>이메일</td>
        <td>
          <input
            type="text"
            id="email"
            v-model="newEmp.email"
            placeholder="이메일을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>고용일</td>
        <td>
          <input
            type="date"
            id="date"
            v-model="newEmp.date"
          />
        </td>
      </tr>
      <tr>
        <td>관리자</td>
        <td>
          <select id="date" v-model="newEmp.super">
            <option disabled value="">선택</option>
            <option value="사장">사장</option>
            <option value="기획부장">기획부장</option>
            <option value="영업부장">영업부장</option>
            <option value="종무부장">종무부장</option>
            <option value="인사부장">인사부장</option>
            <option value="과장">과장</option>
            <option value="영업대표이사">영업대표이사</option>
            <option value="사원">사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>직책</td>
        <td>
          <select id="job" v-model="newEmp.job">
            <option disabled value="">선택</option>
            <option value="사장">사장</option>
            <option value="기획부장">기획부장</option>
            <option value="영업부장">영업부장</option>
            <option value="종무부장">종무부장</option>
            <option value="인사부장">인사부장</option>
            <option value="과장">과장</option>
            <option value="영업대표이사">영업대표이사</option>
            <option value="사원">사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>부서</td>
        <td>
          <input
            type="text"
            id="dep"
            v-model="newEmp.dep"
            placeholder="부서명을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>월급</td>
        <td>
          <input
            type="text"
            id="sal"
            v-model="newEmp.sal"
            placeholder="월급을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>커미션</td>
        <td>
          <input
            type="text"
            id="com"
            v-model="newEmp.com"
            placeholder="커미션을 입력하세요"
          />
        </td>
      </tr>
    </table>
    <br />
    <div>
      <button type="button" @click="add">등록</button>
      <router-link :to="{name: 'list'}">목록</router-link>
    </div>
  </div> `,
  data() {
    return {
      emps: [],
      newEmp: {
        id: 0,
        name: '',
        email: '',
        date: '',
        super: '',
        job: '',
        dep: '',
        sal: '',
        com: '',
      },
      no: 0,
    };
  },
  created() {
    this.emps = localStorage.getItem('emps');
    this.emps = JSON.parse(this.emps);
  },
  methods: {
    add() {
      let newid = 0;
      for (var i = 0; i < this.emps.length; i++) {
        if (this.emps[i].id >= newid) {
          newid = this.emps[i].id + 1; // 새로 작성하는 글번호는 1큰거로!
        }
      }
      this.newEmp.id = newid;
      this.emps.push(this.newEmp);
      localStorage.setItem('emps', JSON.stringify(this.emps));
      alert('등록되었습니다.');
    },
  },
};
