export default {
  template: `
    <div id="app">
      <h2>사원목록</h2>
      <table>
        <thead>
          <tr>
            <th scope="col">사원 아이디</th>
            <th scope="col">사원명</th>
            <th scope="col">부서</th>
            <th scope="col">직책</th>
            <th scope="col">연봉</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="e in newEmp">
            <th scope="row">{{e.id}}</th>
            <td><router-link :to="'/detail/'+e.id">{{e.name}}</router-link></td>
            <td>{{e.dep}}</td>
            <td>{{e.job}}</td>
            <td>{{e.sal}}</td>
          </tr>
        </tbody>
      </table>

      <button
        type="button"
        onclick="location.href='write.html'"
      >
        등록
      </button>
    </div>`,
  data() {
    return {
      emps: [],
      newEmp: [],
    };
  },
  created() {
    this.emps = localStorage.getItem('emps');
    this.emps = JSON.parse(this.emps);
    if (this.emps == null || this.emps.length == 0) {
      this.emps = [
        {
          id: 3,
          name: '장현철',
          eamil: 'ssafy@ssafy.com',
          date: today,
          dep: '기획부',
          super: '사장',
          job: '사원',
          sal: '700',
          com: '100',
        },
        {
          id: 2,
          name: '장길산',
          eamil: 'ssafy@ssafy.com',
          date: today,
          dep: '영업부',
          super: '사장',
          job: '과장',
          sal: '1000',
          com: '100',
        },
        {
          id: 1,
          name: '절취선',
          eamil: 'ssafy@ssafy.com',
          date: today,
          dep: '영업부',
          super: '사원',
          job: '사원',
          sal: '900',
          com: '100',
        },
      ];
      localStorage.setItem('emps', JSON.stringify(this.emps));
    }
    for (let i = 0; i < this.emps.length; i++) {
      this.newEmp.push(this.emps[i]);
    }
  },
};
