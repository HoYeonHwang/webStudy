// 라우트 컴포넌트
import list from './components/list.js';
import detail from './components/detail.js';
import write from './components/write.js';

// 라우터 객체 생성
const router = new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/list',
      name: 'list',
      component: list,
    },
    {
      path: '/detail/:id',
      name: 'detail',
      component: detail,
    },
    {
      path: '/write',
      name: 'write',
      component: write,
    },
  ],
});

// Vue 인스턴트 라우터 주입
const app = new Vue({
  el: '#app',
  router,
});
