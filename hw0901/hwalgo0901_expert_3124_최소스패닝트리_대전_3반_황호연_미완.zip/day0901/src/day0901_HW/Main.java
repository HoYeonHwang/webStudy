import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.StringTokenizer;
import java.util.concurrent.LinkedBlockingDeque;
 
public class Main {
    static int T, V, E;
    static int[][] input;
    static int[] minEdge;
    static boolean[] visited;
 
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        T = Integer.parseInt(st.nextToken());
        for (int test_case = 1; test_case <= T; test_case++) {
            st = new StringTokenizer(br.readLine());
            V = Integer.parseInt(st.nextToken());
            E = Integer.parseInt(st.nextToken());
 
            input = new int[V + 1][V + 1];
            minEdge = new int[V + 1];
            visited = new boolean[V + 1];
 
            for (int i = 1; i <= V; i++) {
                minEdge[i] = Integer.MAX_VALUE;
                visited[i] = false;
            }
             
            for (int i = 0; i < E; i++) {
                st = new StringTokenizer(br.readLine());
                int from = Integer.parseInt(st.nextToken());
                int to = Integer.parseInt(st.nextToken());
                int d = Integer.parseInt(st.nextToken());
                input[from][to] = d;
            }
            int minVertex, min, result = 0;
            minEdge[1] = 0;
            for (int c = 1; c <= V; c++) {
                min = Integer.MAX_VALUE;
                minVertex = 0;
                for (int i = 1; i <= V; i++) {
                    if (!visited[i] && min > minEdge[i]) {
                        min = minEdge[i];
                        minVertex = i;
                    }
                }
                result = result + min;
                visited[minVertex] = true;
                for (int i = 1; i <= V; i++) {
                    if (!visited[i] && input[minVertex][i] != 0 && minEdge[i] > input[minVertex][i]) {
                        minEdge[i] = input[minVertex][i];
                    }
                }
            }
            System.out.println("#"+test_case+" "+result);
        }
    }