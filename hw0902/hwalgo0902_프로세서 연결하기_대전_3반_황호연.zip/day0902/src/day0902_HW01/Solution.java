package day0902_HW01;

import java.util.ArrayList;
import java.util.Scanner;

public class Solution {
	static int N, T,coreCnt;
	static int[][] map;
	static int[] di = { -1, 0, 1, 0 };
	static int[] dj = { 0, 1, 0, -1 };
	static ArrayList<Process> list;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			N=sc.nextInt();
			map=new int[N][N];
			list = new ArrayList<Process>();
			coreCnt=0;
			for(int i=0;i<N;i++) {
				for(int j=0;j<N;j++) {
					if(i!=0&&j!=0&&i!=N-1&&j!=N-1) {
						map[i][j]=sc.nextInt();
					} else {
						sc.nextInt();
					}
				}
				
			}
			for(int i=0;i<N;i++) {
				for(int j=0;j<N;j++) {
					if(map[i][j]==1) {
						coreCnt++;
						list.add(new Process(i,j));
					}
				}
			}
			set(0,0,0);
		}
	}
	public static void set(int current,int cnt,int len) {
		if(current==coreCnt) {
			
			return;
		}
		for(int k=0;k<4;k++) {
			
		}
	}
	static class Process {
		int x, y;

		Process(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
}
