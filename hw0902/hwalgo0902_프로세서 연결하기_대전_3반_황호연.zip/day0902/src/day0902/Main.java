package day0902;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	static int N, Answer;
	static int[] people;
	static boolean[][] local;
	static boolean[] select;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		people = new int[N];
		local = new boolean[N][N];
		select = new boolean[N];
		Answer = Integer.MAX_VALUE;
		for (int i = 0; i < N; i++) {
			people[i] = sc.nextInt();
		}
		for (int i = 0; i < N; i++) {
			int k = sc.nextInt();
			for (int j = 0; j < k; j++) {
				int t = sc.nextInt() - 1;
				local[i][t] = true;
			}
		}
		Combination(0);
		if (Answer == Integer.MAX_VALUE) {
			System.out.println(-1);
		} else {
			System.out.println(Answer);
		}
	}

	public static void Combination(int target) {
		if (target == local.length) {
			int F = 0, S = 0;
			if (!fill_Check(select))
				return;

			for (int i = 0; i < N; i++) {
				if (select[i]) {
					F++;
				} else if (!select[i]) {
					S++;
				}
			}
			System.out.println(Arrays.toString(select)+F+" "+S);
			division(select, F, S);
			return;
		}
		select[target] = true;
		Combination(target + 1);
		select[target] = false;
		Combination(target + 1);
	}

	public static void division(boolean[] check, int F, int S) {
		boolean[] fdiv = new boolean[N];
		boolean[] sdiv = new boolean[N];
		boolean[] div = new boolean[N];
		Arrays.fill(div, false);
		for (int i = 0; i < N; i++) {
			if (select[i]) {
				fdiv[i] = true;
			} else if (!select[i]) {
				sdiv[i] = true;
			}
		}
//		System.out.println("F"+Arrays.toString(fdiv));
//		System.out.println("S"+Arrays.toString(sdiv));

		for (int i = 0; i < N; i++) {
			if (fdiv[i]) {
				if(F==1) {
					div[i]=true;
				}
				for (int j = 0; j < local[i].length; j++) {
					if (local[i][j] && !sdiv[j]) {
						div[j] = true;
					}
				}
			}
		}
//		System.out.println("div"+Arrays.toString(div));
		int cnt = 0;
		for (int i = 0; i < N; i++) {
			if (div[i] && fdiv[i]) {
				cnt++;
			}
		}
		if (cnt != F) {
			return;
		}
		div = new boolean[N];
		for (int i = 0; i < N; i++) {
			if (sdiv[i]) {
				if(S==1) {
					div[i]=true;
				}

				for (int j = 0; j < local[i].length; j++) {
					if (local[i][j] && !fdiv[j]) {
						div[j] = true;
					}
				}
			}
		}
//		System.out.println("div"+Arrays.toString(div));
		cnt = 0;
		for (int i = 0; i < N; i++) {
			if (div[i] && sdiv[i]) {
				cnt++;
			}
		}
		if (cnt != S) {
			return;
		}
		int fsum = 0, ssum = 0;
		for (int i = 0; i < N; i++) {
			if (select[i]) {
				fsum = fsum + people[i];
			} else if (!select[i]) {
				ssum = ssum + people[i];
			}
		}
//		System.out.println("fsum : "+fsum+" ssum : "+ssum);
		Answer = Math.min(Answer, Math.abs(fsum - ssum));
	}

	public static boolean fill_Check(boolean[] check) {
		int T_cnt = 0, F_cnt = 0;
		for (int i = 0; i < N; i++) {
			if (check[i]) {
				T_cnt++;
			} else if (!check[i]) {
				F_cnt++;
			}
		}
		if (T_cnt == N || F_cnt == N) {
			return false;
		}
		return true;
	}
}
