package com.ssafy.hw;

public class Refrigerator {
	private int Re_number;
	private String Re_name;
	private int Re_price;
	private int Re_ea;
	private String Re_size;
	public Refrigerator() {
		
	}
	public Refrigerator(String con_name) {
		Re_name=con_name;
	}
	public int getRe_number() {
		return Re_number;
	}
	public void setRe_number(int re_number) {
		Re_number = re_number;
	}
	public String getRe_name() {
		return Re_name;
	}
	public void setRe_name(String re_name) {
		Re_name = re_name;
	}
	public int getRe_price() {
		return Re_price;
	}
	public void setRe_price(int re_price) {
		Re_price = re_price;
	}
	public int getRe_ea() {
		return Re_ea;
	}
	public void setRe_ea(int re_ea) {
		Re_ea = re_ea;
	}
	public String getRe_size() {
		return Re_size;
	}
	public void setRe_size(String re_size) {
		Re_size = re_size;
	}
	public String toString() {
		return this.Re_number+" "+this.Re_name+" "+this.Re_price+" "+this.Re_ea+" "+this.Re_size+" ";
		}
}
