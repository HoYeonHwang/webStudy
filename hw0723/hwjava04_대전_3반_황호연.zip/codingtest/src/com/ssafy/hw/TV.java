package com.ssafy.hw;

public class TV {
	private int Tv_number;
	private String Tv_Name;
	private int Tv_price;
	private int Tv_ea;
	private int Tv_inch;
	private String Tv_type;
	public TV() {
		
	}
	public TV(String con_name){
		Tv_Name=con_name;
	}
	public int getTv_number() {
		return Tv_number;
	}


	public void setTv_number(int tv_number) {
		Tv_number = tv_number;
	}


	public String getTv_Name() {
		return Tv_Name;
	}


	public void setTv_Name(String tv_Name) {
		Tv_Name = tv_Name;
	}


	public int getTv_price() {
		return Tv_price;
	}


	public void setTv_price(int tv_price) {
		Tv_price = tv_price;
	}


	public int getTv_ea() {
		return Tv_ea;
	}


	public void setTv_ea(int tv_ea) {
		Tv_ea = tv_ea;
	}


	public int getTv_inch() {
		return Tv_inch;
	}


	public void setTv_inch(int tv_inch) {
		Tv_inch = tv_inch;
	}


	public String getTv_type() {
		return Tv_type;
	}


	public void setTv_type(String tv_type) {
		Tv_type = tv_type;
	}

	
	public String toString() {
		return this.Tv_number+" "+this.Tv_Name+" "+this.Tv_price+" "+this.Tv_ea+" "+this.Tv_inch+" "+this.Tv_type;
		}
}
