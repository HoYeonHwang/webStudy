package com.ssafy.hw;

public class ProductTest {
	public static void main(String[] args) {
		TV tv = new TV("�Ｚ  TV");
		tv.setTv_number(1);
		tv.setTv_price(10000);
		tv.setTv_ea(3);
		tv.setTv_inch(27);
		tv.setTv_type("60hz �����");
		System.out.print("��ȣ :"+tv.getTv_number()+" ");
		System.out.print("�̸� :"+tv.getTv_Name()+" ");
		System.out.print("���� :"+tv.getTv_price()+" ");
		System.out.print("���� :"+tv.getTv_ea()+" ");
		System.out.print("��ġ :"+tv.getTv_inch()+" ");
		System.out.println("Ÿ�� :"+tv.getTv_type()+" ");
		System.out.println(tv.toString());
		Refrigerator refrigerator = new Refrigerator("�Ｚ�����"+" ");
		refrigerator.setRe_number(1);
		refrigerator.setRe_price(5000);
		refrigerator.setRe_ea(5);
		refrigerator.setRe_size("100L");
		System.out.print("�̸� :"+refrigerator.getRe_name()+" ");
		System.out.print("��ȣ :"+refrigerator.getRe_number()+" ");
		System.out.print("���� :"+refrigerator.getRe_price()+" ");
		System.out.print("���� :"+refrigerator.getRe_ea()+" ");
		System.out.println("ũ�� :"+refrigerator.getRe_size()+" ");
		System.out.println(refrigerator.toString()+" ");
	}
}
