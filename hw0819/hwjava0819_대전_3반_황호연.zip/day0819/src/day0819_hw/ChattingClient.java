package day0819_hw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class ChattingClient extends JFrame {
	private JPanel pNorth, pSouth;
	private JTextArea ta;
	private JTextField tf;
	private JButton btnSend;
	private JButton btnSave;

	private String nick;
	private String P;
	public ChattingClient() {
		pNorth = new JPanel();
		pSouth = new JPanel();

		ta = new JTextArea();
		tf = new JTextField();
		btnSend = new JButton("send");
		btnSave = new JButton("SAVE");
		
		pNorth.setLayout(new BorderLayout());
		pSouth.setLayout(new BorderLayout());
	
		ta.setEditable(false);
		ta.setBackground(Color.LIGHT_GRAY);

		pNorth.add(new JScrollPane(ta));
		pSouth.add(tf, BorderLayout.CENTER);
		pSouth.add(btnSend, BorderLayout.EAST);
		pSouth.add(btnSave,BorderLayout.WEST);

		add(pNorth, BorderLayout.CENTER);
		add(pSouth, BorderLayout.SOUTH);

		setTitle("채팅 클라이언트 프로그램");
		setSize(300, 400);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		nick = JOptionPane.showInputDialog("닉네임을 입력하세요.");
		P=JOptionPane.showInputDialog("포트를 입력하세요.(7777~7781)");
		
		connect(P);
	}

	private Socket socket;
	private ObjectOutputStream oos,os;
	private ObjectInput ois;

	private void connect(String p) {
		System.out.println("port : "+p);
		try {
			socket = new Socket(InetAddress.getByName("localhost"),7777);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ta.setText("접속하였습니다. "+"port : "+p+"로 이동합니다." + "\n*******************************************************\n");
			oos.writeObject(Integer.parseInt(p));
			socket.close();
			socket = new Socket(InetAddress.getByName("localhost"), Integer.parseInt(p));
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			ta.setText("port : "+p+" 서버에 접속 완료하였습니다. 채팅을 시작하세요!!!" + "\n*******************************************************\n");
			
			nick +="("+socket.getLocalAddress()+")";
			oos.writeObject(nick+"님이 입장하셨습니다." + "\n");

			
			btnSend.addActionListener((e) -> {
				try {
					oos.writeObject(nick+">>"+tf.getText() + "\n");
					tf.setText("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			});
			tf.addActionListener((e) -> {
				try {
					oos.writeObject(nick+">>"+tf.getText() + "\n");
					tf.setText("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			});
			ArrayList<String> list = null;
			btnSave.addActionListener((e) -> {
				try {
					os = new ObjectOutputStream(new FileOutputStream("chat.dat"));
					for(String l : list) {
						os.writeObject(l);
					}
					System.out.println("파일 저장이 완료되었습니다.");
				} catch (IOException e1) {
					e1.printStackTrace();
				} finally {
					if (os != null) {
						try {
							os.close();
						} catch (IOException e2) {
							e2.printStackTrace();
						}
					}
				}
			
				
			});
			while (true) {
				String reciveMsg;
				try {
					reciveMsg = (String) ois.readObject();
					System.out.println("?: "+reciveMsg);
					list.add(reciveMsg);
					ta.append(reciveMsg);
					ta.setCaretPosition(ta.getText().length());
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		ChattingClient frmae = new ChattingClient();
	}
}
