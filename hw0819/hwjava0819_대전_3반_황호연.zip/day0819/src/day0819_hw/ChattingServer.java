package day0819_hw;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ChattingServer {
	private ArrayList<ClientThread> threads = new ArrayList<>();
	
	void broadcast(String msg) {
		for(ClientThread t: threads) {
			t.speak(msg);
		}
	}
	public void service() throws ClassNotFoundException{
		ObjectInput ois;

		Socket socket;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(7777);
			System.out.println("server wait..........");
			socket = serverSocket.accept();
			System.out.println("clinet connect!!"+socket.getInetAddress().getHostName()+"방이동 합니다.");
			ois = new ObjectInputStream(socket.getInputStream());
			Object p = ois.readObject();
			int port = (Integer)p; 
			System.out.println("받은값:"+port);
			socket.close();
			while(true) {
			serverSocket = new ServerSocket(port);
			System.out.println("server loading..........");
			socket = serverSocket.accept();
			System.out.println("clinet connect!!"+socket.getInetAddress().getHostName());
			ClientThread th = new ClientThread(socket);
			threads.add(th);
			th.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("서버 소켓 입장 오류");
			e.printStackTrace();
		}
		
	}
	class ClientThread extends Thread{
		private Socket socket;
		private ObjectOutputStream oos;
		private ObjectInput ois;
		private String nick;
		
		ClientThread(Socket socket) throws ClassNotFoundException {
			this.socket=socket;
			try {
				oos = new ObjectOutputStream(socket.getOutputStream());
				ois = new ObjectInputStream(socket.getInputStream());
				nick = (String) ois.readObject();
				broadcast(nick+"님이 입장하셨습니다.");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		void speak(String sendMsg) {
			try {
				oos.writeObject(sendMsg+"\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("쓰레드가 말하다가 오류남");
				e.printStackTrace();
			}
		}
		
		
		@Override
		public void run() {
			try {
				while(true) {
					String reciveMsg = (String) ois.readObject();
					broadcast(reciveMsg);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("쓰레드가 듣다가 오류남");
				synchronized (threads) {
					broadcast(nick+"님이 퇴장하셨습니다.");
				}
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				if(ois!=null) {
					try {
						ois.close();
					} catch (IOException e) {
						// TODO: handle exception
					}
				}
				if(socket!=null) {
					try {
						socket.close();
					} catch (IOException e) {
						// TODO: handle exception
					}
				}
			}
		}
		
	}
	public static void main(String[] args) throws ClassNotFoundException {
		ChattingServer chattingServer = new ChattingServer();
			chattingServer.service();
		
	}
}
