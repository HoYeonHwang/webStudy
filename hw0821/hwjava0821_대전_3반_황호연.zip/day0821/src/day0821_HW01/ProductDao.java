package day0821_HW01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProductDao {
	private static ProductDao instance = new ProductDao();

	public static ProductDao getInstance() {
		return instance;
	}

	private ProductDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private static Connection conn;
	private static PreparedStatement pstmt;
	private static ResultSet rs;

	public static Connection getconnection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test_db?serverTimezone=UTC", "root", "root");
		} catch (SQLException e) {
			System.out.println("커넥션 생성 오류");
			e.printStackTrace();
		}
		return conn;
	}

	public static void close(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("conn close 오류");
				e.printStackTrace();
			}
		}
	}

	public static void close(PreparedStatement preparedStatement) {
		if (preparedStatement != null) {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				System.out.println("preparedStatement close 오류");
				e.printStackTrace();
			}
		}
	}

	public static void close(ResultSet resultSet) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				System.out.println("resultSet close 오류");
				e.printStackTrace();
			}
		}
	}

	public void insertProduct(Product product) {
		String sql = "INSERT INTO product(ispn,title,price,remain) VALUES (?,?,?,?)";
		conn = getconnection();
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, product.getIspn());
			pstmt.setString(2, product.getTitle());
			pstmt.setInt(3, product.getPrice());
			pstmt.setInt(4, product.getRemain());
			

			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("dao insert 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
	}
	public void updateProduct(String[] st) {
		String sql = "UPDATE product SET price=? WHERE ispn=?";
		conn = getconnection();
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, Integer.parseInt(st[1]));
			pstmt.setInt(2, Integer.parseInt(st[0]));


			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("dao update 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
	}
	public void deleteProduct(String ispn) {
		String sql = "DELETE FROM product WHERE ispn =?";
		conn = getconnection();
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, ispn);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("dao delete 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
	}
	public List<Product> findProduct_title(String title) {
		String sql = "SELECT ispn,title,price,remain FROM product WHERE title LIKE ?";
		conn = getconnection();
		List<Product> list =  new ArrayList<>();
		Product result = null;
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, "%"+title+"%");
			rs = pstmt.executeQuery(); 
			while (rs.next()) {
				result = new Product();
				
				result.setIspn(rs.getString("ispn"));
				result.setTitle(rs.getString("title"));
				result.setPrice(rs.getInt("price"));
				result.setRemain(rs.getInt("remain"));
				list.add(result);
			}
		} catch (SQLException e) {
			System.out.println("dao fineProduct 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
		return list;
	}
	public Product findProduct(String ispn) {
		String sql = "SELECT ispn,title,price,remain FROM product WHERE ispn=?";
		conn = getconnection();
		Product result = null;
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, ispn);
			rs = pstmt.executeQuery(); // sql 실행!
			if (rs.next()) {
				result = new Product();
				
				result.setIspn(rs.getString("ispn"));
				result.setTitle(rs.getString("title"));
				result.setPrice(rs.getInt("price"));
				result.setRemain(rs.getInt("remain"));

			}
		} catch (SQLException e) {
			System.out.println("dao fineProduct 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
		return result;
	}
	public List<Product> findProduct_price(String price) {
		String sql = "SELECT ispn,title,price,remain FROM product WHERE price<=?";
		conn = getconnection();
		List<Product> list =  new ArrayList<>();
		Product result = null;
		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, price);
			rs = pstmt.executeQuery(); // sql 실행!
			while (rs.next()) {
				result = new Product();
				
				result.setIspn(rs.getString("ispn"));
				result.setTitle(rs.getString("title"));
				result.setPrice(rs.getInt("price"));
				result.setRemain(rs.getInt("remain"));
				list.add(result);
			}
		} catch (SQLException e) {
			System.out.println("dao fineProduct 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
		return list;
	}
	public List<Product> listProduct() {
		String sql = "SELECT * FROM product ";
		conn = getconnection();
		List<Product> list =  new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery(); 
			
			while (rs.next()) {
				Product result = new Product();
				
				result.setIspn(rs.getString("ispn"));
				result.setTitle(rs.getString("title"));
				result.setPrice(rs.getInt("price"));
				result.setRemain(rs.getInt("remain"));

				list.add(result);
			}
		} catch (SQLException e) {
			System.out.println("dao listproduct 오류");
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
			close(conn);
		}
		return list;
	}
	public int count() {
		String sql = "SELECT * FROM product ";
		conn = getconnection();
		int cnt =0;
		try {
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				cnt++;
			}
		} catch (SQLException e) {
			System.out.println("dao count 오류");
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(conn);
		}
		
		return cnt;
	}
}
