package day0821_HW01;

public class Product {
	private String ispn;
	private String title;
	private int price;
	private int remain;
	public String getIspn() {
		return ispn;
	}
	public void setIspn(String ispn) {
		this.ispn = ispn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getRemain() {
		return remain;
	}
	public void setRemain(int remain) {
		this.remain = remain;
	}
	@Override
	public String toString() {
		return "Product [ispn=" + ispn + ", title=" + title + ", price=" + price + ", remain=" + remain + "]";
	}
	public Product(String ispn, String title, int price, int remain) {
		this.ispn = ispn;
		this.title = title;
		this.price = price;
		this.remain = remain;
	}
	public Product() {
		
	}
	
}
