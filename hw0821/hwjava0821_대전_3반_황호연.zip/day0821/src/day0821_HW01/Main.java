package day0821_HW01;

import java.awt.print.Book;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.StringTokenizer;

public class Main {
	private static int N;
	static ProductDao productdao = ProductDao.getInstance();
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st;
		while (true) {
			print();
			st= new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			if(N==0) {
				break;
			}
			switch (N) {
			case 1:
				String[] in = new String[4];
				System.out.println("데이터를 입력하세요.");
				st= new StringTokenizer(br.readLine(),",");
				for(int i=0;i<4;i++) {
					in[i]=st.nextToken();
				}
				Product product = new Product(in[0],in[1],Integer.parseInt(in[2]),Integer.parseInt(in[3]));
				productdao.insertProduct(product);
				break;
			case 2:
				List<Product> output = productdao.listProduct();
				for(Product p : output) {
					System.out.println(p.toString());
				}
				break;
			case 3:
				String tispn;
				System.out.println("검색할 상품 명을 입력하세요.");
				st= new StringTokenizer(br.readLine());
				tispn = st.nextToken();
				List<Product> p_t =productdao.findProduct_title(tispn);
				for(Product p : p_t) {
					System.out.println(p.toString());
				}
				
				break;
			case 4:
				String price;
				System.out.println("검색할 가격을 입력하세요.");
				st= new StringTokenizer(br.readLine());
				price = st.nextToken();
				List<Product> p_p =productdao.findProduct_price(price);
				for(Product p : p_p) {
					System.out.println(p.toString());
				}
				break;
				
			case 5:
				String ispn;
				System.out.println("검색할 상품 번호 입력하세요.");
				st= new StringTokenizer(br.readLine());
				ispn = st.nextToken();
				Product p =productdao.findProduct(ispn);
				System.out.println(p.toString());
				
				break;
		
			case 6:
				String disbn;
				System.out.println("삭제할 상품 번호를 입력하세요.");
				st= new StringTokenizer(br.readLine());
				disbn = st.nextToken();
				productdao.deleteProduct(disbn);
				
				break;
				
			case 7:
				String[] in_u= new String[2];
				System.out.println("데이터를 입력하세요.");
				st= new StringTokenizer(br.readLine(),",");
				for(int i=0;i<2;i++) {
					in_u[i]=st.nextToken();
				}
				productdao.updateProduct(in_u);
				break;
			
			default:
				break;
			}
		}
	}


	public static void print() {
		System.out.println("<<Product 관리 프로그램>>");
		System.out.println("1.상품정보 저장");
		System.out.println("2.상품 전체 정보 검색");
		System.out.println("3.상품명 검색");
		System.out.println("4.상품 가격 검색");
		System.out.println("5.제품번호로 검색");
		System.out.println("6.제품번호로 삭제");
		System.out.println("7.제품 가격 업데이트");

	}
}
/*
1000,삼성TV,10000,10
2000,LGTV,14000,4
3000,LGTV,30000,2
 */
