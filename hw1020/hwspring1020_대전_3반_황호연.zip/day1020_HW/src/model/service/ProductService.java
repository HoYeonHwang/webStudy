package model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.dao.ProductDAO;
import model.model.ProductDTO;



@Service
public class ProductService {
	@Autowired
	private ProductDAO dao;
	
	
	public void setProductDao(ProductDAO dao) {
		this.dao = dao;
	}
	
	public List<ProductDTO> getlist() {
		return dao.searchAll();
	}
	
}




