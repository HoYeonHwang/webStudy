package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import model.model.ProductDTO;
import model.utill.DBUtill;


@Repository
public class ProductDAO {

	public int insertProduct(ProductDTO product) {
		
		String sql = "INSERT INTO product"
				+ "(Product_number, Product_title,Product_price,Product_comment)"
				+ "VALUES (?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, product.getProduct_number());
			pstmt.setString(2, product.getProduct_title());
			pstmt.setString(3, product.getProduct_price());
			pstmt.setString(4, product.getProduct_comment());
			
			return pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		
		return 0;
	}
	public List<ProductDTO> searchAll(){
		String sql = "SELECT * FROM product";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int number = rs.getInt("Product_number");
				String title = rs.getString("Product_title");
				String price = rs.getString("Product_price");
				String comment =rs.getString("Product_comment");
				list.add(new ProductDTO(number,title,price,comment));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtill.close(rs);
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		return list;
	}
	public ProductDTO searchLast(){
		String sql = "SELECT * FROM product";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDTO productdto= new ProductDTO();
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int number = rs.getInt("Product_number");
				String title = rs.getString("Product_title");
				String price = rs.getString("Product_price");
				String comment =rs.getString("Product_comment");
				productdto = new ProductDTO(number,title,price,comment);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtill.close(rs);
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		return productdto;
	}
	public List<ProductDTO> searchPrice(int pri){
		String sql = "SELECT * FROM product WHERE Product_price <="+pri+"";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int number = rs.getInt("Product_number");
				String title = rs.getString("Product_title");
				String price = rs.getString("Product_price");
				String comment =rs.getString("Product_comment");
				list.add(new ProductDTO(number,title,price,comment));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtill.close(rs);
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		return list;
	}

	public List<ProductDTO> searchTitle(String title_input) {
		String sql = "SELECT * FROM product WHERE Product_title =?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		try {
			conn = DBUtill.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title_input);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int number = rs.getInt("Product_number");
				String title = rs.getString("Product_title");
				String price = rs.getString("Product_price");
				String comment =rs.getString("Product_comment");
				list.add(new ProductDTO(number,title,price,comment));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtill.close(rs);
			DBUtill.close(pstmt);
			DBUtill.close(conn);
		}
		return list;
	}
	

	
}
