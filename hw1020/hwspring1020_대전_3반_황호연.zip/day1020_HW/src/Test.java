import java.util.List;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.model.ProductDTO;
import model.service.ProductService;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ProductService service = context.getBean(ProductService.class);

		while (true) {
			System.out.println("1:상품 목록  -1:종료");
			int select = sc.nextInt();

			if (select == -1)
				break;

			switch (select) {
			case 1:
				System.out.print("상품 목록  ");
				List<ProductDTO> pdto = service.getlist();
				for (ProductDTO dto : pdto) {
					System.out.println(dto);
				}
				break;
			}
		}

	}
}
