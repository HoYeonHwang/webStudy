package day0811_hw;

public class CodeNotFoundException extends Exception{
	private static final long serialVersionUID = 1L;

	public CodeNotFoundException(String msg) {
		super(msg);
	}
}
