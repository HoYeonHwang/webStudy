package day0811_hw;

import java.util.ArrayList;

public class ProductMgr implements IProductMgr{
	private static ProductMgr instance = new ProductMgr();
	private ProductMgr() {}
	public static ProductMgr getInstance() {
		return instance;
	}
	
	private ArrayList<Product> product = new ArrayList<Product>();
	
	@Override
	public void add(Product p) throws DuplicateException{
		ArrayList<Product> temp = new ArrayList<>();
		for(Product t : product) {
			if(t.getIspn()==(p.getIspn())) {
				throw new DuplicateException("이미 존재하는 상품입니다.");
			}
		}
		product.add(p);
	}
	@Override
	public Product[] list() {
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public Product[] list(int ispn) throws CodeNotFoundException {
		boolean flag = false;
		ArrayList<Product> temp = new ArrayList<>();
		
		for(Product p : product) {
			if(p.getIspn()==ispn) {
				flag = true;
				temp.add(p);
			}
		}
		if(!flag) {
			throw new CodeNotFoundException("상품 번호가 존재하지 않습니다.");
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] list(String title) {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p.getTitle().contains(title)) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] listOneTV() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof TV) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] listOneRF() {
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof Refrigerator) {
				temp.add(p);
			}
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] pickOnRF() throws ProductNotFoundException {
		boolean flag = false;
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof Refrigerator&&((Refrigerator) p).getBig()>=400) {
				flag = true;
				temp.add(p);
			}
		}
		if(!flag) {
			throw new ProductNotFoundException("상품이 존재하지 않습니다.");
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] pickOnTV() throws ProductNotFoundException {
		boolean flag = false;
		ArrayList<Product> temp = new ArrayList<>();
		for(Product p : product) {
			if(p instanceof TV&&((TV) p).getSize()>=50) {
				temp.add(p);
				flag=true;
			}
		}
		if(!flag) {
			throw new ProductNotFoundException("상품이 존재하지 않습니다.");
		}
		return temp.toArray(new Product[temp.size()]);
	}
	@Override
	public Product[] recall(int ispn, int price) {
		for(Product p : product) {
			if(p.getIspn()==ispn) {
				p.setPrice(price);
			}
		}
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public Product[] delete(int ispn) {
		for(int i=0;i<product.size();i++) {
			if(product.get(i).getIspn()==ispn) {
				product.remove(i);
			}
		}
		
		return product.toArray(new Product[product.size()]);
	}
	@Override
	public int AllPrice() {
		if(product.size() == 0) {
			return 0;
		}
		int sum =0;
		for(int i=0;i<product.size();i++) {
			sum = sum +product.get(i).getPrice();
		}
		return sum;
	}
	

	
}
