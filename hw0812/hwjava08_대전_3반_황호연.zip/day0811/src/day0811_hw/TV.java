package day0811_hw;

public class TV extends Product{
	private int size; //크기 
	private String purpose; // 용도
	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public TV(int ispn, String title, int price, int remain, int size, String purpose) {
		super(ispn, title, price, remain);
		this.size = size;
		this.purpose = purpose;
	}

	public TV() {
		
	}

	@Override
	public String toString() {
		return super.toString()+"TV [size=" + size + ", purpose=" + purpose + "]";
	}


	

	
	
}
