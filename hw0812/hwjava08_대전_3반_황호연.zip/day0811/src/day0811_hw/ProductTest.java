package day0811_hw;

import java.util.Arrays;
import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) throws Exception, DuplicateException {
		ProductMgr pmgr = ProductMgr.getInstance();
		Product[] List = new Product[100];
		Scanner sc = new Scanner(System.in);
		while (true) {
			print();
			int N = sc.nextInt();
			sc.nextLine();
			if (N == 0) {
				break;
			}
			switch (N) {
			case 1:
				String[] input = new String[6];
				input = sc.nextLine().split(" ");
				try {
					if (input.length == 6) {
						pmgr.add(new TV(Integer.parseInt(input[0]), input[1], Integer.parseInt(input[2]),
								Integer.parseInt(input[3]), Integer.parseInt(input[4]), input[5]));
					} else
						pmgr.add(new Refrigerator(Integer.parseInt(input[0]), input[1], Integer.parseInt(input[2]),
								Integer.parseInt(input[3]), Integer.parseInt(input[4])));
				} catch (DuplicateException e) {
					System.err.println(e.getClass() + " 발생");
					System.err.println("message : " + e.getMessage());
				}
				
				break;
			case 2:
				List = pmgr.list();
				if(List.length==0) {
					System.err.println("Is Empty!!");
				}
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 3:
				System.out.println(">>찾으실 번호를 입력해주세요");
				int pn = sc.nextInt();
				sc.nextLine();
				try {
					List = pmgr.list(pn);
					if(List.length==0) {
						System.err.println("Is Empty!!");
					}
					for (Product a : List) {
						System.out.println(a.toString());
					}
				} catch (CodeNotFoundException e) {
					System.err.println(e.getClass() + " 발생");
					System.err.println("message : " + e.getMessage());
				}
				
				break;
			case 4:
				System.out.println(">>찾으실 제품명을 입력해주세요");
				String ti = sc.nextLine();
				List = pmgr.list(ti);
				if(List.length==0) {
					System.err.println("Is Empty!!");
				}
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 5:
				List = pmgr.listOneTV();
				System.out.println("<<TV만 검색한 목록입니다.>>");
				if(List.length==0) {
					System.err.println("Is Empty!!");
				}
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 6:
				List = pmgr.listOneRF();
				System.out.println("<<냉장고만 검색한 목록입니다.>>");
				if(List.length==0) {
					System.err.println("Is Empty!!");
				}
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 7:
				try {
					List = pmgr.pickOnRF();
					System.out.println("<<400L 이상의 냉장고 목록입니다.>>");
					if(List.length==0) {
						System.err.println("Is Empty!!");
					}
					for (Product a : List) {
						System.out.println(a.toString());
					}
				} catch (ProductNotFoundException e) {
					System.err.println(e.getClass() + " 발생");
					System.err.println("message : " + e.getMessage());
				}
				
				break;
			case 8:
				try {
					List = pmgr.pickOnTV();
					System.out.println("<<50Inch 이상의 TV 목록입니다.>>");
					if(List.length==0) {
						System.err.println("Is Empty!!");
					}
					for (Product a : List) {
						System.out.println(a.toString());
					}
				} catch (Exception e) {
					System.err.println(e.getClass() + " 발생");
					System.err.println("message : " + e.getMessage());
				}
				
				break;
			case 9:
				boolean value =false;
				System.out.println(">>변경하실 제품번호를 입력해주세요");
				int n = sc.nextInt();
				System.out.println(">>변경하실 상품가격을 입력해주세요");
				int p = sc.nextInt();
				sc.nextLine();
				List = pmgr.recall(n,p);
				for (Product a : List) {
					if(a.getIspn()==n) {
						value=true;
					}
				}
				if(value==false) {
					System.err.println("Not Found");
					break;
				}
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 10:
				System.out.println(">>삭제하실 제품번호를 입력해주세요");
				int del = sc.nextInt();
				sc.nextLine();
				List = pmgr.delete(del);
				System.out.println("<<삭제하고 남은 리스트입니다.>>");
				for (Product a : List) {
					System.out.println(a.toString());
				}
				break;
			case 11:
				int sum = pmgr.AllPrice();
				if(sum==0) {
					System.err.println("Not Calculation");
					break;
				}
				else {
					System.out.println("제품의 총 가격은 : "+sum+"원 입니다.");
				}
				break;
			}
		}
	}

	public static void print() {
		System.out.println("****************");
		System.out.println("<< ABC 디지털 대리점 >>");
		System.out.println("1.상품 정보 저장");
		System.out.println("2.상품 전체 검색");
		System.out.println("3.상품 번호 검색");
		System.out.println("4.상품 명 저장");
		System.out.println("5.TV 정보만 검색");
		System.out.println("6.냉장고 검색");
		System.out.println("7.400L 이상의 Refrigerator 검색");
		System.out.println("8.50inch 이상의 TV 검색");
		System.out.println("9.상품 가격 변경");
		System.out.println("10.상품 번호로 삭제");
		System.out.println("11.전체 재고 금액");
		System.out.println("0.종료");
		System.out.println("****************");

	}
}

/*
1000 삼성TV 1000000 15 27 home 
2001 LGTV 2000000 10 50 board 
2002 LGTV 2500000 5 60 board
 * 
5000 삼성RF 100000 10 100 
6001 LGRF 200000 10 500 
6002 LGRF 300000 5 600
 * 
 * 
 * 
 * 
 * 
 */