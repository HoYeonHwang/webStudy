package SWEA_혁진이의프로그램검증;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;
 
public class Main {
    private static int R, C, dir, number;
    private static char map[][];
    private static int visited[][][][];
    private static boolean cal, bool;
    private static int[] di = { 0, 1, 0, -1 };
    private static int[] dj = { 1, 0, -1, 0 };
    private static Queue<Point> queue = new LinkedList<Point>();
 
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(in.readLine());
        StringBuilder sb = new StringBuilder();
        int T = Integer.parseInt(st.nextToken());
        for (int test_case = 1; test_case <= T; test_case++) {
            st = new StringTokenizer(in.readLine());
            R = Integer.parseInt(st.nextToken());
            C = Integer.parseInt(st.nextToken());
            map = new char[R][C];
            visited = new int[R][C][4][16];
            for (int i = 0; i < R; i++) {
                map[i] = in.readLine().toCharArray();
            }
            queue = new LinkedList<Point>();
            cal = false;
            for (int i = 0; i < R; i++) {
                for (int j = 0; j < C; j++) {
                    if (map[i][j] == '@') {
                        cal = true;
                    }
                }
            }
            for (int i = 0; i < R; i++) {
                for (int j = 0; j < C; j++) {
                    for (int k = 0; k < 4; k++) {
                        Arrays.fill(visited[i][j][k], -1);
                    }
                }
            }
            dir=0;
            number=0;
            if (map[0][0] == '.') {
                number = 0;
            }else if(map[0][0] == '@') {
                cal=false;
            }else if(map[0][0]=='<') {
                dir=2;
            }else if(map[0][0]=='>') {
                dir=0;
            }else if(map[0][0]=='^') {
                dir=3;
            }else if(map[0][0]=='v') {
                dir=1;
            }else if(map[0][0]=='_') {
                dir=2;
            }else if(map[0][0]=='|') {
                dir=1;
            }else if(map[0][0]=='?') {
                cal=false;
            }else if(map[0][0]=='+') {
                number =1;
            }else if(map[0][0]=='-') {
                number=15;
            }else {
                number = map[0][0] - '0';
            }
            queue.offer(new Point(0, 0, number));
            if (cal) {
                boolean key = true;
                while (key) {
                    key = doit(key);
                }
                if (cal) {
                    sb.append("#" + test_case + " " + "YES" + "\n");
                }
                if (!cal) {
                    sb.append("#" + test_case + " " + "NO" + "\n");
                }
            } else if (!cal) {
                if(map[0][0]=='@') {
                    sb.append("#" + test_case + " " + "YES" + "\n");
                }else {
                sb.append("#" + test_case + " " + "NO" + "\n");
                }
            }
        }
        System.out.println(sb);
    }
 
    public static boolean doit(boolean key) {
        Point current = queue.poll();
        int x = current.i + di[dir];
        int y = current.j + dj[dir];
        if (x == -1) {
            x = R-1;
        } else if (x == R) {
            x = 0;
        }
        if (y == -1) {
            y = C-1;
        } else if (y == C) {
            y = 0;
        }
        number = current.n;
//      System.out.println(x + " " + y + " " + number + " " + dir);
        if (map[x][y] == '<') {
            dir = 2;
        } else if (map[x][y] == '>') {
            dir = 0;
        } else if (map[x][y] == '^') {
            dir = 3;
        } else if (map[x][y] == 'v') {
            dir = 1;
        } else if (map[x][y] == '_') {
            dir = (number == 0) ? 0 : 2;
        } else if (map[x][y] == '|') {
            dir = (number == 0) ? 1 : 3;
        } else if (map[x][y] == '?') {
            int temp = dir;
            int tempx = x;
            int tempy = y;
            int tempn = number;
            int[][][][] tempv = visited;
            for (int k = 0; k < 4; k++) {
                queue.offer(new Point(tempx, tempy, tempn));
                dir = k;
                doit(key);
                if (bool) {
                    key = false;
                    return key;
                }
            }
            dir = temp;
            System.out.println("bool : " + bool);
        } else if (map[x][y] == '.') {
 
        } else if (map[x][y] == '+') {
            number = number + 1;
            if (number == 16) {
                number = 0;
            }
        } else if (map[x][y] == '-') {
            number = number - 1;
            if (number == -1) {
                number = 15;
            }
        } else if (map[x][y] == '@') {
            key = false;
            bool = true;
            return key;
        } else {
            number = map[x][y] - '0';
        }
        if (visited[x][y][dir][number] == number) {
            key = false;
            cal = false;
            return key;
        }
        visited[x][y][dir][number] = number;
        queue.offer(new Point(x, y, number));
        return key;
    }
 
    static class Point {
        int i, j, n;
 
        Point(int i, int j, int n) {
            this.i = i;
            this.j = j;
            this.n = n;
        }
    }
}