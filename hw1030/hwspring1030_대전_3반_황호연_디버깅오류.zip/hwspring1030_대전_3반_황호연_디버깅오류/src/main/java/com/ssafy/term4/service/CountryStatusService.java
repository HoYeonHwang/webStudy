package com.ssafy.term4.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.term4.model.dto.CountryStatus;
import com.ssafy.term4.model.mapper.CountryStatusMapper;

@Service
public class CountryStatusService {
	@Autowired
	private SqlSession sqlSession;
	
	public boolean registStatus(CountryStatus dto) {
		if(sqlSession.getMapper(CountryStatusMapper.class).insertCountryStatus(dto) == 1) {
			return true;
		}
		return false;
	}
	
	public List<CountryStatus> getStatusList(){
		return sqlSession.getMapper(CountryStatusMapper.class).selectList();
	}
	
	public CountryStatus getDetail(String ccode) {
		return sqlSession.getMapper(CountryStatusMapper.class).selectOne(ccode);
	}
	
	public boolean delete(String ccode) {
		if(sqlSession.getMapper(CountryStatusMapper.class).delete(ccode) == 1)
			return true;
		return false;
	}
}
