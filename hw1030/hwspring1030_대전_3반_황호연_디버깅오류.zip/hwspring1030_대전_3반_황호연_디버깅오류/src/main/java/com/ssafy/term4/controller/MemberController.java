package com.ssafy.term4.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.term4.model.dto.Member;
import com.ssafy.term4.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	private MemberService mservice;
	
	@GetMapping("login")
	public String getLogin() {
		return "index";
	}
	
	@PostMapping("login")
	public String login(@RequestParam Map<String, String> paramMap, HttpServletRequest request, Model model) {
		String id = paramMap.get("id");
		String pw = paramMap.get("pw");
		
		Member member = mservice.userCheck(id, pw);
		
		if(member == null) { // 존재하지 않는 유저
			return "index";
		}
		HttpSession session = request.getSession();
		session.setAttribute("loginInfo", member);
		
		model.addAttribute("id", id);
		
		return "regist";
	}
	
	@GetMapping("logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "index";
	}
}
