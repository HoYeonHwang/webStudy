package com.ssafy.term4.controller;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.term4.model.dto.CountryStatus;
import com.ssafy.term4.service.CountryStatusService;

@Controller
public class CountryStatusController {
	@Autowired
	private CountryStatusService csservice;
	
	@GetMapping("regist")
	public String getRegist() {
		return "regist";
	}
	
	@PostMapping("regist")
	public String regist(CountryStatus dto, Model model) {
		if(csservice.registStatus(dto)) {
			model.addAttribute("cname", dto.getCname());
			return "result";
		} else {
			model.addAttribute("errMsg", "현황 등록 중 오류가 발생했습니다.");
			return "views/error";
		}
	}
	
	@GetMapping("list")
	public String getList(Model model) {
		List<CountryStatus> statusList = csservice.getStatusList();
		
		model.addAttribute("statusList", statusList);
		
		return "list";
	}
	
	@GetMapping("detail")
	public String getDetail(@Param("ccode") String ccode, Model model) {
		CountryStatus dto = csservice.getDetail(ccode);
		
		model.addAttribute("dto", dto);
		return "detail";
	}
	
	@GetMapping("deleteList")
	public String delete(@RequestParam Map<String, String> paramMap, Model model) {
		for(String key : paramMap.keySet()) {
			if(!csservice.delete(paramMap.get(key))) {
				model.addAttribute("errMsg", "목록 삭제 중 오류가 발생했습니다.");
				return "error";
			}
		}
		return "deleteResult";
	}
}
