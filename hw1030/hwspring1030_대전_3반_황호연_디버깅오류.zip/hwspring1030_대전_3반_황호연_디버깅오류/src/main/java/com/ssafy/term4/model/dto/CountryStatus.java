package com.ssafy.term4.model.dto;

public class CountryStatus {
	private String ccode;
	private String cname;
	private int patient;
	private String rcode;
	private String rname;

	public CountryStatus() {
	};

	public CountryStatus(String ccode, String cname, int patient, String rcode) {
		this.ccode = ccode;
		this.cname = cname;
		this.patient = patient;
		this.rcode = rcode;
	}

	public CountryStatus(String ccode, String cname, int patient, String rcode, String rname) {
		super();
		this.ccode = ccode;
		this.cname = cname;
		this.patient = patient;
		this.rcode = rcode;
		this.rname = rname;
	}

	public String getCcode() {
		return ccode;
	}

	public void setCcode(String ccode) {
		this.ccode = ccode;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getPatient() {
		return patient;
	}

	public void setPatient(int patient) {
		this.patient = patient;
	}

	public String getRcode() {
		return rcode;
	}

	public void setRcode(String rcode) {
		this.rcode = rcode;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	@Override
	public String toString() {
		return "CountryStatus [ccode=" + ccode + ", cname=" + cname + ", patient=" + patient + ", rcode=" + rcode + "]";
	}

}
