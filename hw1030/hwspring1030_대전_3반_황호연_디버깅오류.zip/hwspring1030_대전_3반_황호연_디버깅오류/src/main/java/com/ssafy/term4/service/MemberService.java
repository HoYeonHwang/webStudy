package com.ssafy.term4.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.term4.model.dto.Member;
import com.ssafy.term4.model.mapper.MemberMapper;


@Service
public class MemberService {
	@Autowired
	private SqlSession sqlSession;
	
	public Member userCheck(String id, String pw) {
		return sqlSession.getMapper(MemberMapper.class).selectUseridAndUserpwd(id, pw);
	}
}
