package com.ssafy.term4.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssafy.term4.model.dto.CountryStatus;

public interface CountryStatusMapper {
	public CountryStatus checkCcode(@Param("ccode") String ccode);
	public int insertCountryStatus(CountryStatus dto);
	public List<CountryStatus> selectList();
	public CountryStatus selectOne(@Param("ccode") String ccode);
	public int delete(@Param("ccode") String ccode);
}
