package com.ssafy.term4.model.mapper;

import org.apache.ibatis.annotations.Param;

import com.ssafy.term4.model.dto.Member;

public interface MemberMapper {
	public Member selectUseridAndUserpwd(@Param("id") String id, @Param("pw") String pw);
}
