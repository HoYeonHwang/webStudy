package SWEA_수영장;

import java.util.Scanner;

public class Main {
	static int day, month, threemonth, year, Answer;
	static int[] ticket, ticket_price;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			ticket = new int[4];
			ticket_price = new int[12];
			
			Answer = Integer.MAX_VALUE;
			for (int k = 0; k < 4; k++) {
				ticket[k] = sc.nextInt();
			}
			Answer = Math.min(Answer, ticket[3]);
			for (int k = 0; k < 12; k++) {
				ticket_price[k] = sc.nextInt();
			}
			dfs(0,0);
			
			System.out.println("#" + test_case + " " + Answer);
		}
	}
	public static void dfs(int month, int price) {
		if(month > 11) {
			Answer = Math.min(Answer,price);
			return;
		}
		if(ticket_price[month] ==0) {
			dfs(month+1,price);
		}else {
			dfs(month+1,price+(ticket[0]*ticket_price[month]));
			dfs(month+1,price+ticket[1]);
			dfs(month+3,price+ticket[2]);
		}
	}
}
