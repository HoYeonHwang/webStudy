package hw0805;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class hw0805_02 {
	private static int N, cnt,temp;
	private static int[][] map;
	private static int[] Answer;
	static int[] deli = { -1, 0, 1, 0 };
	static int[] delj = { 0, 1, 0, -1 };
	static boolean[][] visited;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Queue<home> queue = new LinkedList<home>();
		N = sc.nextInt();
		sc.nextLine();
		String[][] str = new String[N][N];
		String[] line = new String[N];
		visited=new boolean[N][N];
		map = new int[N][N];
		Answer = new int[N*N];
		cnt=0;
		for(int i=0;i<N;i++) {
			line[i]=sc.nextLine();
		}
		for (int i = 0; i < N; i++) {
			str[i]=line[i].split("");
			for(int j=0;j<N;j++) {
			map[i][j]=Integer.parseInt(str[i][j]);
			}
		}
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				if(map[i][j]==1&&!visited[i][j]) {
					temp=0;
					queue.offer(new home(i,j));
					visited[i][j]=true;
					temp++;
					while(!queue.isEmpty()) {
						home current = queue.poll();
						for(int k=0;k<4;k++) {
							if(current.x+deli[k]>=0&&current.x+deli[k]<N&&current.y+delj[k]>=0&&current.y+delj[k]<N&&map[current.x+deli[k]][current.y+delj[k]]==1&&!visited[current.x+deli[k]][current.y+delj[k]]) {
								queue.offer(new home(current.x+deli[k],current.y+delj[k]));
								visited[current.x+deli[k]][current.y+delj[k]]=true;
								temp++;
							}
						}
					}
					Answer[cnt]=temp;
					cnt++;
				}
			}
		}
		Arrays.sort(Answer);
		System.out.println(cnt);
		for(int i=0;i<N*N;i++) {
			if(Answer[i]!=0) {
			System.out.println(Answer[i]);
			}
		}
	}

	static class home {
		int x, y;

		home(int i, int j) {
			x = i;
			y = j;
		}
	}
}
