package hw0805;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class hw0805_01 {
	static int W, H, Answer;
	static int[][] map;
	static int[] deli = { -1, -1, 0, 1, 1, 1, 0, -1 };
	static int[] delj = { 0, 1, 1, 1, 0, -1, -1, -1 };
	static int T;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {

			Queue<land> queue = new LinkedList<land>();

			Answer = 0;
			W = sc.nextInt();
			H = sc.nextInt();
			if (W == 0 && H == 0) {
				break;
			}
			map = new int[H][W];

			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++) {
					if (map[i][j] == 1) {
						queue.offer(new land(i, j));
						map[i][j] = 2;
						while (!queue.isEmpty()) {
							land current = queue.poll();
							for (int k = 0; k < 8; k++) {
								if (current.x + deli[k] >= 0 && current.x + deli[k] < H && current.y + delj[k] >= 0
										&& current.y + delj[k] < W
										&& map[current.x + deli[k]][current.y + delj[k]] == 1) {
									queue.offer(new land(current.x + deli[k], current.y + delj[k]));
									map[current.x + deli[k]][current.y + delj[k]] = 2;
								}
							}
						}
						Answer++;
					}
				}
			}
			System.out.println(Answer);
		}
	}

	static class land {
		int x, y;

		land(int i, int j) {
			x = i;
			y = j;
		}
	}
}
