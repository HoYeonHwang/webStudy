package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.MemberDTO;
import util.DBUtil;

public class MemberDAO {
	private MemberDAO() {}
	private static MemberDAO instance = new MemberDAO();
	public static MemberDAO getInstance() {
		return instance;
	}
////////////////////////////////////////////////////////////////////////////////
	public int insertMember(MemberDTO member) {
		String sql = "INSERT INTO MEMBER_TB"
				+ " (USER_ID, USER_PW, USER_NAME, USER_EMAIL, USER_ADDRESS, USER_ADDRESS2) VALUES(?,?,?,?,?,?)";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, member.getUserId());
			pstmt.setString(2, member.getUserPw());
			pstmt.setString(3, member.getUserName());
			pstmt.setString(4, member.getUserEmail());
			pstmt.setString(5, member.getUserAddress());
			pstmt.setString(6, member.getUserAddress2());
			
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		
		return 0;
	}
	
	public String selectMember(String id) {
		String sql = "SELECT USER_PW FROM MEMBER_TB WHERE USER_ID=? ";
		String temp=null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		
		return null;
	}
}


