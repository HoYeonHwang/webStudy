package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDAO;

@WebServlet("/idCheck")
public class CheckIdServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userId = req.getParameter("userId");
		
		String pw = MemberDAO.getInstance().selectMember(userId);
		System.out.println("pw : " + pw);
		if(pw==null) {
			pw="";
		}
		resp.getWriter().write(pw); // 해당 아이디로 조회된 패스워드를 줌. 없으면 null
	}
}
