package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDAO;
import model.MemberDTO;

@WebServlet("/join")
public class JoinServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 회원가입 창에서 입력한 정보들을 받아서
		System.out.println("doPost");
		String userName = req.getParameter("userName");
		String userId = req.getParameter("userId");
		String userPw = req.getParameter("userPw");
		String userAddress = req.getParameter("userAddress");
		String userAddress2 = req.getParameter("userAddress2");
		String userEmail = req.getParameter("userEmail");
		
		MemberDTO member = new MemberDTO(userId, userPw, userName, userEmail, userAddress, userAddress2);
		System.out.println(member.toString());
		MemberDAO.getInstance().insertMember(member); // db에 들어감.
	}
}








