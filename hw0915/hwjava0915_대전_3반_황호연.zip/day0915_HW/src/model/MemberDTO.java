package model;

//USER_ID varchar(20) primary key,
//USER_PW varchar(20) not null,
//USER_NAME varchar(10) not null,
//USER_EMAIL varchar(50) not null,
//USER_ADDRESS varchar(50) not null,
//USER_ADDRESS2 varchar(50)

public class MemberDTO {
	private String userId;
	private String userPw;
	private String userName;
	private String userEmail;
	private String userAddress;
	private String userAddress2;
//////////////////////////////////////////////////////////////////////////////	
	public MemberDTO() {}
	
	public MemberDTO(String userId, String userPw, String userName, String userEmail, String userAddress,
			String userAddress2) {
		this.userId = userId;
		this.userPw = userPw;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userAddress = userAddress;
		this.userAddress2 = userAddress2;
	}
/////////////////////////////////////////////////////////////////////////////////	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPw() {
		return userPw;
	}

	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserAddress2() {
		return userAddress2;
	}

	public void setUserAddress2(String userAddress2) {
		this.userAddress2 = userAddress2;
	}

	@Override
	public String toString() {
		return "MemberDTO [userId=" + userId + ", userPw=" + userPw + ", userName=" + userName + ", userEmail="
				+ userEmail + ", userAddress=" + userAddress + ", userAddress2=" + userAddress2 + "]";
	}
}
