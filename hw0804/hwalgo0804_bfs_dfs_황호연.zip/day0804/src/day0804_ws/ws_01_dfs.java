package day0804_ws;

import java.util.Arrays;
import java.util.Scanner;

public class ws_01_dfs {
	private static int[] visited = new int[101];
	private static boolean[][] dfs = new boolean[101][101];
	private static int  max, Answer, dist;
	private static int[] arr = new int[101];
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		for (int test_case = 1; test_case <= 10; test_case++) {
			int N = sc.nextInt();
			int S = sc.nextInt();
			int cnt=0;
			arr= new int[101];
			Answer = 0;
			max = 0;
			dist = 0;
			for (int i = 0; i < N / 2; i++) {
				int from = sc.nextInt();
				int to = sc.nextInt();
				dfs[from][to] = true;
			}
			int current = S;
			dfs_re(current);
			System.out.println();
			System.out.println();
			for(int i=0;i<101;i++) {
				System.out.println(i+": "+visited[i]);
			}
			for(int i=0;i<101;i++) {
				if(visited[i]>=max) {
					max=visited[i];
				}
			}
			System.out.println(max);
			for(int i=0;i<101;i++) {
				if(visited[i]==max) {
					arr[cnt]=i;
					cnt++;
				}
			}
			Arrays.sort(arr);
			System.out.println(Arrays.toString(arr));
			Answer=arr[arr.length-1];
			System.out.println("#" + test_case + " " + Answer);
		}
	}

	public static void dfs_re(int current) {
		dist++;
		visited[current]=dist;
		System.out.println(current+": "+dist);
		for (int i = 0; i < 101; i++) {
			if (dfs[current][i] == true && visited[i]==0) {
				dfs_re(i);
				dist--;
			}
		}

	}
	
}
