package day0804_ws;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ws_01_bfs {
	public static void main(String args[]) throws Exception {

		Queue<Integer> queue = new LinkedList<Integer>();
		Scanner sc = new Scanner(System.in);

		for (int test_case = 1; test_case <= 10; test_case++) {

			boolean[][] bfs = new boolean[101][101];
			boolean visited[] = new boolean[101];

			int N = sc.nextInt();
			int S = sc.nextInt();
			int Answer=0;
			for (int i = 0; i < N / 2; i++) {
				int from = sc.nextInt();
				int to = sc.nextInt();
				bfs[from][to] = true;
			}

			int current = S;
			visited[current] = true;

			for (int i = 0; i < 101; i++) {
				if (bfs[current][i] == true) {
					queue.offer(i);
					visited[i] = true;
				}
			}
			while (!queue.isEmpty()) {
				int q_size = queue.size();
				Answer=0;
				for (int k = 0; k < q_size; k++) {
					current = queue.poll();
					if(Answer<current) {
						Answer=current;
					}
					for (int i = 0; i < 101; i++) {
						if (bfs[current][i] && !visited[i]) {
							queue.offer(i);
							visited[i] = true;
						}
					}
				}
			}
			System.out.println("#"+test_case+" "+Answer);
		}
	}
}
