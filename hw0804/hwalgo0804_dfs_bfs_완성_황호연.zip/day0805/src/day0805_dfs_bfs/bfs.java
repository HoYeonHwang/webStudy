package day0805_dfs_bfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class bfs {
	static int[][] bfs;
	static int Answer;
	static boolean[] visited;
	static boolean[] exist; // 연속적이지 않은 것일 수 있음
	static int N, start;
	static int maxDist; // 출발점에서 가장 먼거리

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = 10;
		for (int test_case = 1; test_case <= T; test_case++) {
			bfs = new int[101][101];
			Answer = 0;
			visited = new boolean[101];
			exist = new boolean[101];
			N = sc.nextInt();
			start = sc.nextInt();
			maxDist = 0;
			for (int i = 0; i < N / 2; i++) {
				int st = sc.nextInt();
				int end = sc.nextInt();
				bfs[st][end] = 1;
				exist[st] = true;
				exist[end] = true;
			}

//			// BFS ver1 : 탐색하면서 방문하는 각 정점마다 거리를 같이 기록해 놓기
//			Queue<Student> queue = new LinkedList<dfs_bfs.Student>();
//			queue.offer(new Student(start, 0));
//			visited[start] = true;
//			
//			ArrayList<Student> candidate = new ArrayList<>();
//			while (!queue.isEmpty()) {
//				Student now = queue.poll();
//				for (int i = 1; i <= 100; i++) {
//					if (bfs[now.num][i] == 1 && !visited[i]) {
//						queue.offer(new Student(i, now.dist + 1));
//						visited[i] = true;
//					}
//				}
//				if(now.dist>maxDist) { //거리가 커지면 지금까지 모았던 애들 버리고
//					candidate.clear();
//					candidate.add(now);
//					maxDist= now.dist;
//				}else if(now.dist==maxDist) { //거리가 같으면 일단 모으고
//					candidate.add(now);
//				}
//			}
//
//			for(int i=0;i<candidate.size();i++) {
//				if(candidate.get(i).num>Answer) {
//					Answer=candidate.get(i).num;
//				}
//			}
			// BFS ver2. : 큐에서 꺼낼때
			Queue<Integer> queue = new LinkedList<Integer>();
			queue.offer(start);
			visited[start] = true;
			int dist = 0;
			while (!queue.isEmpty()) {
				int size = queue.size();
				ArrayList<Integer> candidate = new ArrayList<Integer>();
				for (int s = 0; s < size; s++) {
					int now = queue.poll();
					candidate.add(now);
					for (int i = 1; i <= 100; i++) {
						if (bfs[now][i] == 1 && !visited[i]) {
							queue.offer(i);
							visited[i] = true;
						}
					}
				} // 출발점에서 거리가 같은 애들 다 poll한 시점
				if (maxDist < dist) {
					maxDist = dist;
				}
				dist++;
			}
			System.out.println("#" + test_case + " " + Answer);

		}
	}

	static class Student {
		int num;
		int dist;

		Student(int n, int d) {
			num = n;
			dist = d;
		}
	}
}
