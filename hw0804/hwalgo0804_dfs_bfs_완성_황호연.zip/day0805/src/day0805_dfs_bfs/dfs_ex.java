package day0805_dfs_bfs;

import java.util.Arrays;
import java.util.Scanner;

public class dfs_ex {
	static int[][] dfs;
	static int Answer;
	static int[] dist;
	static int N, start;
	static int maxDist; // 출발점에서 가장 먼거리

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = 10;
		for (int test_case = 1; test_case <= T; test_case++) {
			dfs = new int[101][101];
			Answer = 0;
			dist = new int[101];
			N = sc.nextInt();
			start = sc.nextInt();
			maxDist = 0;
			for (int i = 0; i < N / 2; i++) {
				int st = sc.nextInt();
				int end = sc.nextInt();
				dfs[st][end] = 1;
			}
			// DFS : 일단 다른애들 연락 가능하더라도 한놈만 선택해서 연락 돌려보기.
			Arrays.fill(dist, Integer.MAX_VALUE);
			dfs(start, 0);
			for(int i=1;i<=100;i++) {
				if(dist[i]!=Integer.MAX_VALUE &&maxDist <=dist[i]) {
					maxDist=dist[i];
					Answer=i;
				}
			}
			System.out.println("#" + test_case + " " + Answer);

		}
	}

	static void dfs(int now, int cnt) {
		dist[now] = cnt;
		for (int i = 1; i <= 100; i++) {
			if (dfs[now][i] == 1 && dist[i] > cnt + 1) {
				dfs(i, cnt + 1);
			}
		}
	}
}
