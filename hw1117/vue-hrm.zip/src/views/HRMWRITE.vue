<template>
  <div id="app" class="wrapper">
    <h2>SSAFY HRM ADD EMPLOEE</h2>
    <table>
      <tr>
        <td>이름</td>
        <td>
          <input
            type="text"
            id="name"
            class="form-control"
            v-model="newEmp.name"
            placeholder="사원명을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>이메일</td>
        <td>
          <input
            type="text"
            id="mailid"
            class="form-control"
            v-model="newEmp.email"
            placeholder="이메일을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>고용일</td>
        <td>
          <input
            type="date"
            id="start_date"
            class="form-control"
            v-model="newEmp.date"
          />
        </td>
      </tr>
      <tr>
        <td>관리자</td>
        <td>
          <select id="manager_id" v-model="newEmp.super" class="form-control">
            <option disabled value="">선택</option>
            <option value="사장">사장</option>
            <option value="기획부장">기획부장</option>
            <option value="영업부장">영업부장</option>
            <option value="종무부장">종무부장</option>
            <option value="인사부장">인사부장</option>
            <option value="과장">과장</option>
            <option value="영업대표이사">영업대표이사</option>
            <option value="사원">사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>직책</td>
        <td>
          <select id="title" v-model="newEmp.job" class="form-control">
            <option disabled value="">선택</option>
            <option value="사장">사장</option>
            <option value="기획부장">기획부장</option>
            <option value="영업부장">영업부장</option>
            <option value="종무부장">종무부장</option>
            <option value="인사부장">인사부장</option>
            <option value="과장">과장</option>
            <option value="영업대표이사">영업대표이사</option>
            <option value="사원">사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>부서</td>
        <td>
          <input
            type="text"
            id="dept_id"
            v-model="newEmp.dep"
            class="form-control"
            placeholder="부서명을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>월급</td>
        <td>
          <input
            type="text"
            id="salary"
            v-model="newEmp.sal"
            class="form-control"
            placeholder="월급을 입력하세요"
          />
        </td>
      </tr>
      <tr>
        <td>커미션</td>
        <td>
          <input
            type="text"
            id="commission_pct"
            v-model="newEmp.com"
            class="form-control"
            placeholder="커미션을 입력하세요"
          />
        </td>
      </tr>
    </table>

    <br />
    <div>
      <button type="button" class="btn btn-primary" @click="add">등록</button>
      <button type="cancel" class="btn btn-warning">
        <router-link :to="{ name: '/list' }">취소</router-link>
      </button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      newEmp: {
        id: 0,
        name: '',
        mailid: '',
        start_date: '',
        manager_id: '',
        title: '',
        dept_id: '',
        salary: '',
        commission_pct: '',
      },
      no: 0,
    };
  },
  methods: {
    add() {
      axios
        .post('http://localhost:8097/hrmboot/api/employee', this.newEmp)
        .then((response) => {
          console.log(response);
          alert('등록되었습니다.');
        })
        .catch()
        .finally();
    },
  },
};
</script>
