<template>
  <div class="container">
    <h1>SSAFY 사원목록</h1>
    <button class="btn btn-success" style="text-align:right;" v-on:click="add">
      등록
    </button>
    <table border="1" class="table table-hover" style="margin-top:10px;">
      <tr>
        <th colspan="6" style="color:green;">
          목록
        </th>
      </tr>
      <tr>
        <th>사원아이디</th>
        <th>사원명</th>
        <th>부서</th>
        <th>직책</th>
        <th>연봉</th>
      </tr>
      <tr v-for="item in items" v-bind:key="item.id">
        <td>{{ item.id }}</td>
        <td>{{ item.name }}</td>
        <td>{{ item.title }}</td>
        <td>{{ item.dept_id }}</td>
        <td>{{ item.salary }}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      items: [],
    };
  },
  created() {
    axios
      .get('http://localhost:8097/hrmboot/api/employee/all')
      .then((response) => {
        console.log(response);
        this.items = response.data;
      })
      .catch()
      .finally();
  },
  methods: {
    add: function() {
      this.$router.push('/write');
    },
  },
};
</script>
