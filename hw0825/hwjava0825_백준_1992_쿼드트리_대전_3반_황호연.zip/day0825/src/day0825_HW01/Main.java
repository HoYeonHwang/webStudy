package day0825_HW01;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	private static int N;
	private static int[][] map;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		map = new int[N][N];
		for(int i=0;i<N;i++) {
			String st = sc.next();
			String[] s = st.split("");
			for(int j=0;j<N;j++) {
				map[i][j]=Integer.parseInt(s[j]);
			}
		}
		
		Division(0,0,N);
	}
	public static void Division(int row,int col,int n) {
		int flag = map[row][col];
		boolean c=true;
		for(int i=row;i<row+n;i++) {
			for(int j=col;j<col+n;j++) {
				if(flag!=map[i][j])
				c=false;
			}
		}
		if(c) {
			System.out.print(flag);
		}
		else {
			System.out.print("(");
		int current_size = n/2;
		for(int i=0;i<2;i++) {
			for(int j=0;j<2;j++) {
				Division(row+current_size*i,col+current_size*j,current_size);
			}
		}
		System.out.print(")");
		}
	}
}
