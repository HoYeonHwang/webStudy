package hw;

import java.util.Arrays;
import java.util.Scanner;

public class dal {
	private static int m, mi = 0, col = -1, sign = 1,N, cnt = 1;

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T;
		T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			N = sc.nextInt();
			m=N;
			mi=0;
			col=-1;
			sign=1;
			cnt=1;
			int[][] map = new int[m][m];
			while (true) {
				for (int i = 0; i < m; i++) {
					col = col + sign;
					map[mi][col] = cnt++;
				}
				m--;
				if (m == 0)
					break;
				for (int i = 0; i < m; i++) {
					mi = mi + sign;
					map[mi][col] = cnt++;
				}
				sign = sign * (-1);
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.print(" "+map[i][j]+" ");
				}
				System.out.println();
			}
		}
	}
}
