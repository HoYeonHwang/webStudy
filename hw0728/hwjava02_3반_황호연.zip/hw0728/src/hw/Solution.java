package hw;

import java.util.Scanner;

class Solution {
	private static int N = 100;
	private static int Answer;

	public static void main(String args[]) throws Exception {
		Answer = 0;
		Scanner sc = new Scanner(System.in);
		int T = 0;
		for (int test_case = 1; test_case <= 10; test_case++) {
			int x = 0, y = 0;
			int[][] map = new int[N][N];
			int[] lo = new int[2]; // 0우 1 좌
			T = sc.nextInt();
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			for (int j = 0; j < N; j++) {
				if (map[N - 1][j] == 2) {
					x = N - 1;
					y = j;
				}
			}
			while (true) {
				if (y+1<N&&map[x][y + 1] == 1 && lo[1] != 1) {
					lo[0] = 1;
					y++;
				} else if (y-1>=0&&map[x][y - 1] == 1 && lo[0] != 1) {
					lo[1] = 1;
					y--;
				} else if (map[x - 1][y] == 1) {
					lo[0] = 0;
					lo[1] = 0;
					x--;
				}
				if (x == 0) {
					Answer = y;
					break;
				}
			}
			System.out.println("#" + T + " " + Answer);
		}
	}

}