package com.ssafy.product.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.ProductDTO;
import com.ssafy.product.mapper.ProductMapper;

@Service
public class ProductService {
	@Autowired
	private SqlSession sqlsession;
	
	public List<ProductDTO> getIdList(){
		List<ProductDTO> dto = sqlsession.getMapper(ProductMapper.class).getIdList();
		return dto;
	}
	public ProductDTO getItem(int Product_number) {
		ProductDTO dto = sqlsession.getMapper(ProductMapper.class).getItem(Product_number);
		return dto;
	}
	public int addItem(ProductDTO dto) {
		int result = sqlsession.getMapper(ProductMapper.class).addItem(dto);
		return result;
	}
	public int editItem(ProductDTO dto) {
		int result = sqlsession.getMapper(ProductMapper.class).editItem(dto);
		return result;
	}
	public int delItem(int Product_number) {
		int result = sqlsession.getMapper(ProductMapper.class).delItem(Product_number);
		return result;
	}
}
