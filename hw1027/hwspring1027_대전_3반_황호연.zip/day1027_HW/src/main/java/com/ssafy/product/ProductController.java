package com.ssafy.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.ProductDTO;
import com.ssafy.product.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService productservice;
	
	@RequestMapping(value = "/product.hhy", method = RequestMethod.GET, produces = "application/json; charset=utf8")
	public List<ProductDTO> getIdList(){
		List<ProductDTO> result = productservice.getIdList();
		return result;
	}
	
	@GetMapping(value = "/product.hhy/{pnum}",  headers = { "Content-type=application/json" })
	public ProductDTO getItem(@PathVariable("pnum") int Product_number) {
		ProductDTO result = productservice.getItem(Product_number);
		return result;
	}
	@PostMapping(value = "/product.hhy",  headers = { "Content-type=application/json" })
	public List<ProductDTO> addItem(@RequestBody ProductDTO dto) {
		productservice.addItem(dto);
		List<ProductDTO> result = productservice.getIdList();
		return result;
	}
	@PutMapping(value = "/product.hhy",  headers = { "Content-type=application/json" })
	public List<ProductDTO> editItem(@RequestBody ProductDTO dto) {
		productservice.editItem(dto);
		List<ProductDTO> result = productservice.getIdList();
		return result;
	}
	@DeleteMapping(value = "/product.hhy/{pnum}",  headers = { "Content-type=application/json" })
	public List<ProductDTO> delItem(@PathVariable("pnum") int Product_number) {
		productservice.delItem(Product_number);
		List<ProductDTO> result = productservice.getIdList();
		return result;
	}
}
