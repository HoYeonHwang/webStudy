package com.ssafy.product.mapper;

import java.util.List;

import com.ssafy.product.dto.ProductDTO;

public interface ProductMapper {
	public List<ProductDTO> getIdList();
	public ProductDTO getItem(int Product_number);
	public int addItem(ProductDTO dto);
	public int editItem(ProductDTO dto);
	public int delItem(int Product_number);
}
