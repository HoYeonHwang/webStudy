package BeakJoon_2583;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
	public static int M, N, K, Answer;
	public static ArrayList<Integer> list = new ArrayList<>();
	public static StringBuilder StB = new StringBuilder();
	public static int[] Size;
	public static int[][] map;
	public static boolean[][] visited;
	public static int[] di = { 0, 0, -1, 1 };
	public static int[] dj = { -1, 1, 0, 0 };
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		M = sc.nextInt();
		N = sc.nextInt();
		Size = new int[M * N];
		map = new int[M][N];
		visited = new boolean[M][N];
		K = sc.nextInt();
		for (int k = 0; k < K; k++) {
			int si = sc.nextInt();
			int sj = sc.nextInt();
			int li = sc.nextInt();
			int lj = sc.nextInt();
			for (int i = M-lj; i < M-sj; i++) {
				for (int j = si; j < li; j++) {
					map[i][j] = 1;
				}
			}
		}
		int cnt = 0;
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				if (!visited[i][j] && map[i][j] == 0) {
					bfs(i, j);
				}
			}
		}
		
		Collections.sort(list);
		for(int size : list) {
			StB.append(size+ " ");
		}
		
		System.out.println(Answer);
		System.out.println(StB.toString());
		
	}

	public static void bfs(int si, int sj) {
		Queue<Land> queue = new LinkedList<Land>();
		int size = 0;
		queue.offer(new Land(si, sj));
		visited[si][sj] = true;
		while (!queue.isEmpty()) {
			Land land = queue.poll();
			size++;
			for (int k = 0; k < 4; k++) {
				int ni = land.i + di[k];
				int nj = land.j + dj[k];
				if (ni >= 0 && ni < M && nj >= 0 && nj < N && map[ni][nj] == 0 && !visited[ni][nj]) {
					queue.offer(new Land(ni, nj));
					visited[ni][nj] = true;
				}
			}
		}
		list.add(size);
		Answer++;
		
	}

	public static class Land {
		int i, j;

		Land(int i, int j) {
			this.i = i;
			this.j = j;
		}
	}
}
