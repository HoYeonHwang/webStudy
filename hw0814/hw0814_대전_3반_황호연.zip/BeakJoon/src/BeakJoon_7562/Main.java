package BeakJoon_7562;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
	private static int I, si, sj, cnt, Answer, li, lj;
	private static int[][] map;
	private static int[][] visited;
	private static int[] di = { -1, -2, -2, -1, 1, 2, 2, 1 };
	private static int[] dj = { -2, -1, 1, 2, 2, 1, -1, -2 };

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			I = sc.nextInt();
			si = sc.nextInt();
			sj = sc.nextInt();
			li = sc.nextInt();
			lj = sc.nextInt();
			cnt = 0;
			Answer = Integer.MAX_VALUE;
			map = new int[I][I];
			visited = new int[I][I];
			bfs(si, sj);
            System.out.println(Answer);
		}
	}
	public static void bfs(int si, int sj) {
		int w = 1;
		Queue<Night> queue = new LinkedList<Night>();
		queue.offer(new Night(si,sj));
		visited[si][sj]=w;
		while(!queue.isEmpty()) {
			int S=queue.size();
			w++;
			for(int s=0;s<S;s++) {
				Night n = queue.poll();
				if(n.i==li&&n.j==lj) {
					Answer=w-2;
				}
				for(int k=0;k<8;k++) {
					int ni = n.i+di[k];
					int nj = n.j+dj[k];
					if(ni>=0&&nj>=0&&ni<I&&nj<I&&visited[ni][nj]==0) {
						queue.offer(new Night(ni,nj));
						visited[ni][nj]=w;
					}
				}
			}
		}
	}
	public static class Night{
		int i,j;
		Night(int i,int j){
			this.i=i;
			this.j=j;
		}
	}
}
