package BeakJoon_11399;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	static int[] I;
	static int N,Answer;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N=sc.nextInt();
		I = new int[N];
		for(int i=0;i<N;i++) {
			I[i]=sc.nextInt();
		}
		Arrays.sort(I);
		for(int i=0;i<N;i++) {
			for(int j=N-i;j>0;j--) {
				Answer=Answer+I[i];
			}
		}
		System.out.println(Answer);
	}
}
