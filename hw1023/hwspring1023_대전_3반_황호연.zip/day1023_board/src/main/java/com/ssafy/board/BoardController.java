package com.ssafy.board;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.board.dto.BoardDto;
import com.ssafy.board.dto.BoardPageDto;
import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.service.BoardService;
import com.ssafy.board.service.CommentService;

// 서블릿이 일시키면 비즈니스 로직을 수행해서 데이터를 응답해야 함.
@Controller
public class BoardController {

/////////////////////////////////////////////////////////////////////////////
	@Autowired
	private BoardService boardService;
	
	@Autowired
	private CommentService commentService;

	@RequestMapping(value = "/BoardList.hhy", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam(value = "page", required = false) String pageStr) {
		ModelAndView mv = new ModelAndView("BoardList");
		int page = 1;
		if (pageStr == null || pageStr.equals("")) {
			page = 1;
		} else {
			page = Integer.parseInt(pageStr);
		}
		BoardPageDto pageDto = boardService.makePage(page);
		mv.addObject("blist", pageDto);
		return mv;
	}

	@RequestMapping(value = "/addForm.hhy", method = RequestMethod.GET)
	public String addForm() {
		return "writeForm";
	}

	@RequestMapping(value = "/add.hhy", method = RequestMethod.POST,produces = "text/json; charset=utf8")
	public String add(@RequestParam("btitle") String title,@RequestParam("bcontent") String content, Model model,HttpSession session) { // ModelAndView 대신 jsp한테 보낼 데이터를 model에 담으면 알아서 감.
		if (session.getAttribute("loginInfo") == null) {
			return "loginCheck";
		}
		MemberDto loginInfo = (MemberDto) session.getAttribute("loginInfo");
		int result = boardService.insertBoard(title,content,loginInfo);
		model.addAttribute("addCount", result);
		return "writeResult";
	}
	
	@RequestMapping(value = "/read.hhy", method = RequestMethod.GET)
	public String getBoard(@RequestParam("bnum") int bnum,Model model) {
		BoardDto dto = boardService.getBoard(bnum);
		model.addAttribute("board",dto);
		return "read" ; // 글 꺼내기
	}
	
	@RequestMapping(value = "/comment.hhy", method = RequestMethod.GET, produces = "text/json; charset=utf8")
	@ResponseBody
	public String getCommentList(@RequestParam("bnum") int bnum){ // bnum번 게시글에 달린 댓글 목록 가져오기.
		String result = commentService.getCommentList(bnum);
		return result;
	}
	
	@RequestMapping(value = "/comment.hhy", method = RequestMethod.POST)
	@ResponseBody
	public String writeComment(@RequestParam("bnum") int bnum,@RequestParam("content") String content,HttpSession session){ 
		String result = null;
		MemberDto loginInfo = (MemberDto) session.getAttribute("loginInfo");
		if(commentService.writeComment(bnum, content,loginInfo)) {
			result="success";
		}else {
			result="fail";
		}
		return result;
	}
}
