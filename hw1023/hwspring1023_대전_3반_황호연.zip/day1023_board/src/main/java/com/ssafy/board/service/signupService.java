package com.ssafy.board.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.mapper.MemberMapper;

@Service
public class signupService {
	@Autowired
	private SqlSession sqlSession;
	
	public int sign(String userid , String userpwd,String username, String email,String address) {
		MemberDto dto = new MemberDto();
		dto.setUserid(userid);
		dto.setUserpwd(userpwd);
		dto.setUsername(username);
		dto.setEmail(email);
		dto.setAddress(address);
		int result =  sqlSession.getMapper(MemberMapper.class).sign(dto);
		return result;
	}
}
