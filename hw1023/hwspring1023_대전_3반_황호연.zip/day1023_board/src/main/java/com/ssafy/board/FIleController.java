package com.ssafy.board;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.board.dto.MyFileDto;
import com.ssafy.board.service.FileService;

@Controller
public class FIleController {
	
	@Autowired
	private FileService fservice;
	
	@GetMapping("/upload.hhy")
	public String upload() {
		return "uploadForm";
	}
	
	@PostMapping("/upload.hhy")
	public ModelAndView upload(MyFileDto dto) {
		String path = "c:/springFiles/";
		
		File dir = new File(path);
		if(!dir.exists()) // 파일 저장할 폴더가 없으면
			dir.mkdir(); // 폴더를 생성해라
		
		String savedName = path+new Random().nextInt(100000000);
		File saveFile = new File(savedName); // 사용자가 업로드한 파일을 저장하기 위한 비어있는 파일을 하나 만듬. 이름은 랜덤.
		
		try {
			dto.getUploadFile().transferTo(saveFile); // 사용자가 보낸 파일을 서버의 폴더에 저장시키는 작업!
			String str = new String(dto.getUploadFile().getOriginalFilename().getBytes("8859_1"),"utf-8"); // 한국 개발자의 설움 .. 
			dto.setFilename(str); // 클라이언트가 업로드한 이름
			dto.setOrigin(saveFile.getAbsolutePath()); // 실제 서버에 저장된 이름.
			fservice.saveFile(dto); // db에 기록하시오.
			
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		ModelAndView mv = new ModelAndView("uploadResult");
		mv.addObject("dto", dto);
		return mv;
	}
	
	@GetMapping("/fileList.hhy")
	public String fileList(Model model) {
		model.addAttribute("fileList", fservice.selectAll());
		return "fileList";
	}
	
	//1. redirect
	//2. cookie
	//3. html응답이 아닐때
	@GetMapping("/download.hhy")
	public void download(int fno, HttpServletResponse response) {
		MyFileDto dto = fservice.searchFile(fno);
		
		response.setContentType("application/octet-stream; charset=UTF-8"); // 이번 응답은 html이 아니라 파일이다.
		response.setHeader("Content-Disposition", "attachment; filename=\""+dto.getFilename()+"\"");
		
		try {
			FileInputStream is = new FileInputStream(dto.getOrigin());// 서버에 저장된 파일 읽어서
			
			ServletOutputStream os = response.getOutputStream();
			
			int data = 0;
			while((data=is.read())!= -1)
				os.write(data);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}
