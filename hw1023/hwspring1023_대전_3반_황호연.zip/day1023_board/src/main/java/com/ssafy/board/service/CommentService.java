package com.ssafy.board.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ssafy.board.dto.CommentDto;
import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.mapper.CommentMapper;

@Service
public class CommentService {
	@Autowired
	private SqlSession sqlSession;
	
	
	public String getCommentList(int bnum){
		List<CommentDto> dto = sqlSession.getMapper(CommentMapper.class).selectCommentList(bnum);
		Gson gs = new Gson();
		String result = gs.toJson(dto);
		return result;
	}
	
	public boolean writeComment(int bnum, String content,MemberDto loginInfo) {
		CommentDto dto = new CommentDto(bnum, loginInfo.getUserid(), content, null);
		
		if(sqlSession.getMapper(CommentMapper.class).insertComment(dto)==1) {
			return true;
		}
		return false;
	}
	
}
