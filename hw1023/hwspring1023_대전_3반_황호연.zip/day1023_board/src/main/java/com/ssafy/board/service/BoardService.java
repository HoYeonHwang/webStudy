package com.ssafy.board.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.dto.BoardDto;
import com.ssafy.board.dto.BoardPageDto;
import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.mapper.BoardMapper;
import com.ssafy.board.mapper.CommentMapper;


// 서블릿이 일시키면 비즈니스 로직을 수행해서 데이터를 응답해야 함.
@Service
public class BoardService {
	public static final int COUNT_PER_PAGE = 10;

/////////////////////////////////////////////////////////////////////////////
	@Autowired
	private SqlSession sqlSession;
		
	public BoardPageDto makePage(int curPage) {
		int totalCnt = sqlSession.getMapper(BoardMapper.class).selectTotalCount(); // 총 게시글 갯수 조회해서
		int totalPageCnt = totalCnt/COUNT_PER_PAGE; // 총 필요한 페이지수 계산(다음, 이전 링크 관련)
		if(totalCnt%COUNT_PER_PAGE>0) 
			totalPageCnt++;
		
		int startPage = (curPage-1)/10*10+1; // ex) 11
		int endPage = startPage+9; //ex) 20
		
		if(totalPageCnt<endPage) // 마지막 페이지가 15이니까 20으로 계산하면 안댐.
			endPage = totalPageCnt;
		
		int startRow = (curPage-1)*10; // 현재 페이지에 보여질 글 조회
		List<BoardDto> boardList = sqlSession.getMapper(BoardMapper.class).selectPage(startRow, COUNT_PER_PAGE);
		
		for(BoardDto dto: boardList) {
			int cmtCnt = sqlSession.getMapper(CommentMapper.class).selectCommentCount(dto.getBnum()); // 해당 게시글에 댓글이 몇개 달렸나 조회해서
			dto.setCmtCnt(cmtCnt); // 해당 게시글 dto에 댓글 갯수 첨부하자.
		}
		
		return new BoardPageDto(boardList, curPage, startPage, endPage, totalPageCnt);
	}
	
	public int insertBoard(String title, String content, MemberDto loginInfo) {
		BoardDto dto = new BoardDto();
		dto.setBtitle(title);
		dto.setBcontent(content);
		dto.setBwriter(loginInfo.getUserid());
		dto.setBreadCnt(0);
		
		return sqlSession.getMapper(BoardMapper.class).insertBoard(dto);
	}

	public int insertBoard(BoardDto dto) {
		return sqlSession.getMapper(BoardMapper.class).insertBoard(dto);
	}
	
	public BoardDto getBoard(int bnum) {
		sqlSession.getMapper(BoardMapper.class).updateReadcnt(bnum);
		return sqlSession.getMapper(BoardMapper.class).selectBoard(bnum);
	}
	
}




