package com.ssafy.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.service.LoginService;
import com.ssafy.board.service.signupService;

@Controller
public class LoginController {
	@Autowired
	private LoginService loginservice;
	@Autowired
	private signupService signupservice;
	
	@RequestMapping(value = "/login.hhy", method = RequestMethod.GET)
	public String getLogin() {
		System.out.println("?");
		return "Login";
	}
	
	@RequestMapping(value = "/login.hhy", method = RequestMethod.POST)
	public String postLogin(@RequestParam("userid") String userid,@RequestParam("userpwd") String userpwd, Model model, HttpServletRequest req) {
		MemberDto dto = loginservice.idpw(userid, userpwd);
		System.out.println(userid+"/"+userpwd);
		if (dto == null) {
			model.addAttribute("msg", "아이디나 비밀번호를 확인하세요.");
			return "login";
		}
		HttpSession session = req.getSession();
		session.setAttribute("loginInfo", dto);		
		
		model.addAttribute("loginInfo", dto);
		return "home";
	}
	@RequestMapping(value = "/logout.hhy", method = RequestMethod.GET)
	public String getLogout(Model model, HttpServletRequest req) {
	
		HttpSession session = req.getSession();
		session.invalidate();
		
		return "home";
	}
	@RequestMapping(value = "/signup.hhy", method = RequestMethod.GET)
	public String signup() {
		return "signup";
	}
	@RequestMapping(value = "/signup.hhy", method = RequestMethod.POST)
	public String postsignup(@RequestParam("userid") String userid,@RequestParam("userpwd") String userpwd,@RequestParam("username") String username,@RequestParam("email") String email,@RequestParam("address") String address, Model model, HttpServletRequest req) {
		int result = signupservice.sign(userid, userpwd, username, email, address);
		System.out.println(userid+"/"+userpwd);
		if (result == 0) {
			model.addAttribute("msg", "회원가입실패");
			return "signup";
		}
		return "home";
	}
}
