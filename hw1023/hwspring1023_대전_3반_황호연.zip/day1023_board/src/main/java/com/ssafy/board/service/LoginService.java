package com.ssafy.board.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.dto.MemberDto;
import com.ssafy.board.mapper.MemberMapper;

@Service
public class LoginService {

	@Autowired
	private SqlSession sqlSession;

	public MemberDto idpw(String userid, String userpwd) {
		MemberDto dto = new MemberDto();
		dto.setUserid(userid);
		dto.setUserpwd(userpwd);
		dto = sqlSession.getMapper(MemberMapper.class).selectWithIdAndPw(dto);
		return dto;
	}
}
