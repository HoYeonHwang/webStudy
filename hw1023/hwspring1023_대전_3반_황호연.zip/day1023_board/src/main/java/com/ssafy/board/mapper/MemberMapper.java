package com.ssafy.board.mapper;

import com.ssafy.board.dto.MemberDto;

public interface MemberMapper {
	public MemberDto selectWithIdAndPw(MemberDto dto);
	public int sign(MemberDto dto);
}
