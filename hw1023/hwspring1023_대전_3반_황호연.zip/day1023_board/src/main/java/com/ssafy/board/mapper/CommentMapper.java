package com.ssafy.board.mapper;


import java.util.List;

import com.ssafy.board.dto.CommentDto;

public interface CommentMapper {
	public int selectCommentCount(int bnum);
	public List<CommentDto> selectCommentList(int bnum);
	public int insertComment(CommentDto dto);
}
