package com.ssafy.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssafy.board.dto.BoardDto;

public interface BoardMapper {
    public int selectTotalCount(); // 총 게시글 갯수
    public List<BoardDto> selectPage(@Param("startRow")int startRow, @Param("cnt") int cnt); // 특정 갯수의 게시글 조회
    public int insertBoard(BoardDto dto); // 게시글 추가
    public int updateReadcnt(int bnum); // 조회수증가
    public BoardDto selectBoard(int bnum); // 게시글 1개 조회
}