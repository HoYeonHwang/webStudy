package com.ssafy.board.mapper;

import java.util.List;

import com.ssafy.board.dto.MyFileDto;

public interface FIleMapper {
	public int insertFile(MyFileDto dto);
	public List<MyFileDto> selectAll();
	public MyFileDto selectOne(int fno);
}
