package paris;

import java.util.Scanner;

public class paris {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T,N,M;
		T = sc.nextInt();
		for (int test_case = 1; test_case <= T; test_case++) {
			int sum = 0,temp=0;
			N = sc.nextInt();
			M = sc.nextInt();
			int[][] map = new int[N][N];
			System.out.print("#" + test_case + " ");
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					map[i][j] = sc.nextInt();
				}
			}
			int x = 0, y = 0;
			while (true) {
				while (true) {
					for (int i = x; i < x + M; i++) {
						for (int j = y; j < y + M; j++) {
							temp = temp + map[i][j];
						}
					}
					if (temp > sum) {
						sum = temp;
					}
					temp = 0;
					y++;
					if(y==N-M+1) {
						y=0;
						break;
					}
				}
				x++;
				if (x == N-M+1) {
					break;
				}
			}
			System.out.println(sum);
		}
	}
}
