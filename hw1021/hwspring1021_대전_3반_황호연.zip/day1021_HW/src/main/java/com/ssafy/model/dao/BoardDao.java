package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.BoardDto;

@Repository
public class BoardDao {
	private BoardDao() {}
	private static BoardDao instance = new BoardDao();
	public static BoardDao getInstance() {
		return instance;
	}
///////////////////////////////////////////////////////////	
	// 총 게시글 갯수
	public int selectTotalCount() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM SSAFY_BOARD";
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			rs.next();
			result = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result;
	}
	
	// 한 페이지에 보여질 글들 조회해서 꺼내오기
	public ArrayList<BoardDto> selectPage(int startRow, int cnt){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<BoardDto> result = new ArrayList<BoardDto>();
		
		String sql = "SELECT BNUM, BTITLE, BWRITER, BREAD_CNT, BWRITEDATE FROM SSAFY_BOARD "+
						" ORDER BY BNUM DESC LIMIT ?,?";
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, cnt);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int bn = rs.getInt(1);
				String title = rs.getString(2);
				String writer = rs.getString(3);
				int readCnt = rs.getInt(4);
				String date = rs.getString(5); // 날짜정보가 문자열로 잘 읽어지려나 .. 
				BoardDto dto = new BoardDto(bn, title, writer, readCnt, date, null); // 하나의 row를 dto에 담아서
				result.add(dto); // 리스트에 추가
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result; // 게시글 list 결과 리턴
	}
	
//	// 게시글 작성
	public int insertBoard(BoardDto dto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "INSERT INTO SSAFY_BOARD (BTITLE, BWRITER, BREAD_CNT, BWRITEDATE, BCONTENT) "+
				" VALUES(?,?,?,NOW(),?)";
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getBtitle());
			pstmt.setString(2, dto.getBwriter());
			pstmt.setInt(3, dto.getBreadCnt());
			pstmt.setString(4, dto.getBcontent());
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result;
	}
	
	// 조회수 증가
	public int updateReadcnt(int bnum) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "UPDATE SSAFY_BOARD SET BREAD_CNT = BREAD_CNT+1 WHERE BNUM=?";
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bnum);
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result;
	}
	
	// 글 읽기 할 때 한개의 글 조회하기
	public BoardDto selectBoard(int bnum) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardDto result = null;
		
		String sql = "SELECT BNUM, BTITLE, BWRITER, BREAD_CNT, BWRITEDATE, BCONTENT FROM SSAFY_BOARD WHERE BNUM=?";
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bnum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int bn = rs.getInt(1);
				String title = rs.getString(2);
				String writer = rs.getString(3);
				int readCnt = rs.getInt(4);
				String date = rs.getString(5); // 날짜정보가 문자열로 잘 읽어지려나 .. 
				String content = rs.getString(6);
				result = new BoardDto(bn, title, writer, readCnt, date, content); // 하나의 row를 dto에 담아서
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result; // 게시글 list 결과 리턴
	}
}
