package com.ssafy.model.dto;
import java.util.ArrayList;

// 목록보기 기능 구현시 화면에 보여져야 하는 정보들을 하나로 묶어주기 위한 dto(==vo == bean) 클래스
public class BoardPageDto {
	private ArrayList<BoardDto> boardList;
	private int curPage;
	private int startPage;
	private int endPage;
	private int totalPage;
////////////////////////////////////////////////////////////////////////////////////////	
	public BoardPageDto() {}
	
	public BoardPageDto(ArrayList<BoardDto> boardList, int curPage, int startPage, int endPage, int totalPage) {
		this.boardList = boardList;
		this.curPage = curPage;
		this.startPage = startPage;
		this.endPage = endPage;
		this.totalPage = totalPage;
	}
/////////////////////////////////////////////////////////////////////////////////////////	
	public ArrayList<BoardDto> getBoardList() {
		return boardList;
	}
	public void setBoardList(ArrayList<BoardDto> boardList) {
		this.boardList = boardList;
	}
	public int getCurPage() {
		return curPage;
	}
	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
	
}
