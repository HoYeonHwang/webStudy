package com.ssafy.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.ssafy.model.dao.BoardDao;
import com.ssafy.model.dao.CommentDao;
import com.ssafy.model.dto.BoardDto;
import com.ssafy.model.dto.BoardPageDto;
import com.ssafy.model.dto.CommentDto;
import com.ssafy.model.dto.MemberDto;

// 서블릿이 일시키면 비즈니스 로직을 수행해서 데이터를 응답해야 함.
@Controller
public class BoardService {
	public static final int COUNT_PER_PAGE = 10;

/////////////////////////////////////////////////////////////////////////////
	@Autowired
	private BoardDao dao;
	
	@Autowired
	private CommentDao cdao; // 댓글 테이블에 디비작업 하는 애
	

	@GetMapping("/BoardList.hhy")
	public ModelAndView list(@RequestParam(value = "page",required=false) String pageStr) {
		ModelAndView mv = new ModelAndView("BoardList");
		int page =1;
		if(pageStr==null||pageStr.equals("")) {
			page = 1;
		}else {
			page = Integer.parseInt(pageStr);
		}
		BoardPageDto pageDto = makePage(page);
		mv.addObject("blist",pageDto);
		return mv;
	}
	@RequestMapping(value="/addForm.hhy",method=RequestMethod.GET)
	public String addForm() {
		return "writeForm";
	}
	
	@PostMapping("/add.hhy")
	public String add(BoardDto dto, Model model) { // ModelAndView 대신 jsp한테 보낼 데이터를 model에 담으면 알아서 감.
		dto.setBwriter("ssafy");
		int result = dao.insertBoard(dto);
		model.addAttribute("addCount",result);
		return "writeResult";
	}
	
	public BoardPageDto makePage(int curPage) {
		int totalCnt = dao.selectTotalCount(); // 총 게시글 갯수 조회해서
		int totalPageCnt = totalCnt/COUNT_PER_PAGE; // 총 필요한 페이지수 계산(다음, 이전 링크 관련)
		if(totalCnt%COUNT_PER_PAGE>0) 
			totalPageCnt++;
		
		int startPage = (curPage-1)/10*10+1; // ex) 11
		int endPage = startPage+9; //ex) 20
		
		if(totalPageCnt<endPage) // 마지막 페이지가 15이니까 20으로 계산하면 안댐.
			endPage = totalPageCnt;
		
		int startRow = (curPage-1)*10; // 현재 페이지에 보여질 글 조회
		ArrayList<BoardDto> boardList = dao.selectPage(startRow, COUNT_PER_PAGE);
		
		for(BoardDto dto: boardList) {
			int cmtCnt = cdao.selectCommentCount(dto.getBnum()); // 해당 게시글에 댓글이 몇개 달렸나 조회해서
			dto.setCmtCnt(cmtCnt); // 해당 게시글 dto에 댓글 갯수 첨부하자.
		}
		
		return new BoardPageDto(boardList, curPage, startPage, endPage, totalPageCnt);
	}
	
	public boolean write(String title, String content, MemberDto loginInfo) {
		BoardDto dto = new BoardDto();
		dto.setBtitle(title);
		dto.setBcontent(content);
		dto.setBwriter(loginInfo.getUserid());
		dto.setBreadCnt(0);
		
		if(dao.insertBoard(dto)==1) // 글작성 완료
			return true;
		else // 글 작성 실패
			return false;
	}
	
	@GetMapping("/read.hhy")
	public ModelAndView getBoard(@RequestParam("bnum") int bnum) {
		dao.updateReadcnt(bnum); // 읽기전에 조회수부터 증가 시키고
		ModelAndView mv = new ModelAndView("read");
		mv.addObject("board",dao.selectBoard(bnum));
		return mv; // 글 꺼내기
	}
	
	@GetMapping("/comment.hhy")
	@ResponseBody
	public String getCommentList(@RequestParam("bnum") int bnum){ // bnum번 게시글에 달린 댓글 목록 가져오기.
		List<CommentDto> dto = cdao.selectCommentList(bnum);
		for(CommentDto d :dto) {
			System.out.println(d.getCcontent());
		}
		Gson gs = new Gson();
		String result = gs.toJson(dto);
		return result; 
	}
	
	@PostMapping("/commentwrite.hhy")
	public boolean writeComment(@RequestParam("bnum") int bnum,@RequestParam("content") String content) {
		CommentDto dto = new CommentDto(bnum, "ssafy", content, null);
		System.out.println(dto.getBnum()+"/" +dto.getCwriter()+"/"+dto.getCcontent());
		if(cdao.insertComment(dto)==1) {
			return true;
		}
		return false;
	}
	
}




