package com.ssafy.model.dto;

public class BoardDto {
	private int bnum; // 글번호
	private String btitle; // 제목
	private String bwriter; // 작성자
	private int breadCnt; // 조회수
	private String bwriteDate; // 작성일시
	private String bcontent;// 글 내용
	
	private int cmtCnt; // 댓글 갯수
////////////////////////////////////////////////////////////////////////////
	public BoardDto() {}
	public BoardDto( String btitle, String bwriter, int breadCnt, String bwriteDate, String bcontent) {
		this.btitle = btitle;
		this.bwriter = bwriter;
		this.breadCnt = breadCnt;
		this.bwriteDate = bwriteDate;
		this.bcontent = bcontent;
	}
	public BoardDto(int bnum, String btitle, String bwriter, int breadCnt, String bwriteDate, String bcontent) {
		this.bnum = bnum;
		this.btitle = btitle;
		this.bwriter = bwriter;
		this.breadCnt = breadCnt;
		this.bwriteDate = bwriteDate;
		this.bcontent = bcontent;
	}
////////////////////////////////////////////////////////////////////////////
	public int getCmtCnt() {
		return cmtCnt;
	}
	
	public void setCmtCnt(int cmtCnt) {
		this.cmtCnt = cmtCnt;
	}
	
	public int getBnum() {
		return bnum;
	}

	
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}

	public String getBtitle() {
		return btitle;
	}

	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}

	public String getBwriter() {
		return bwriter;
	}

	public void setBwriter(String bwriter) {
		this.bwriter = bwriter;
	}

	public int getBreadCnt() {
		return breadCnt;
	}

	public void setBreadCnt(int breadCnt) {
		this.breadCnt = breadCnt;
	}

	public String getBwriteDate() {
		return bwriteDate;
	}

	public void setBwriteDate(String bwriteDate) {
		this.bwriteDate = bwriteDate;
	}

	public String getBcontent() {
		return bcontent;
	}

	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	@Override
	public String toString() {
		return "BoardDto [bnum=" + bnum + ", btitle=" + btitle + ", bwriter=" + bwriter + ", breadCnt=" + breadCnt
				+ ", bwriteDate=" + bwriteDate + ", bcontent=" + bcontent + "]";
	}
}
