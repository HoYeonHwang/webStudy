package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.CommentDto;


@Repository
public class CommentDao {
	private static CommentDao instance = new CommentDao();
	private CommentDao() {}
	public static CommentDao getInstance() {
		return instance;
	}
///////////////////////////////////////////////////////////////////////////////////////
	public int selectCommentCount(int bnum) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM SSAFY_COMMENT WHERE BNUM=?";
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, bnum);
			rs = pstmt.executeQuery();
			
			rs.next();
			result = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result;
	}
	
	
	public ArrayList<CommentDto> selectCommentList(int bnum){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<CommentDto> result = new ArrayList<CommentDto>();
		
		String sql = "SELECT * FROM SSAFY_COMMENT WHERE BNUM=?";
		
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bnum);			
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int cn = rs.getInt("CNUM");
				String writer = rs.getString("CWRITER");
				String date = rs.getString("CWRITEDATE"); // 날짜정보가 문자열로 잘 읽어지려나 ..
				String content = rs.getString("CCONTENT");
				
				CommentDto dto = new CommentDto(cn,bnum,writer,content,date);
				result.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result; // 댓글 list 결과 리턴
	}
	
	public int insertComment(CommentDto dto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = " INSERT INTO SSAFY_COMMENT(BNUM, CWRITER, CCONTENT, CWRITEDATE) "
					+" VALUES(?,?,?,NOW()) ";
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getBnum());
			pstmt.setString(2, dto.getCwriter());
			pstmt.setString(3, dto.getCcontent());
			
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return result;
	}
}




