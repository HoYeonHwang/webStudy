package SWEA_미생물;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	private static int N, M, K, Answer, map[][][];
	private static Point cluster[];
	private static int[] di = { -1, 1, 0, 0 };
	private static int[] dj = { 0, 0, -1, 1 };

	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(in.readLine());
		StringBuilder sb = new StringBuilder();
		int T = Integer.parseInt(st.nextToken());
		for (int test_case = 1; test_case <= T; test_case++) {
			st = new StringTokenizer(in.readLine());
			N = Integer.parseInt(st.nextToken()); // 셀의 갯수 N N
			M = Integer.parseInt(st.nextToken()); // 격리 시간 M 초후에 끝나야함
			K = Integer.parseInt(st.nextToken()); // 미생물의 군집 갯수
			map = new int[N][N][4]; //0더해진 값 1군집 왕 2방향 3 전에있던군집
			cluster = new Point[K+1];
			Answer=0;
			for (int k = 1; k <= K; k++) {
				st = new StringTokenizer(in.readLine());
				int i = Integer.parseInt(st.nextToken());
				int j = Integer.parseInt(st.nextToken());
				int n = Integer.parseInt(st.nextToken());
				int d = Integer.parseInt(st.nextToken())-1;
				cluster[k] = new Point(i, j, n, d);
			}
			int count = 0;
			while (true) {
				if (count == M) {
					for(int i=0;i<N;i++) {
						for(int j=0;j<N;j++) {
							Answer= Answer+map[i][j][0];
						}
					}
					break;
				}
				init();
				for (int k = 1; k <= K; k++) {
					if (cluster[k].num != 0) {
						int dir = cluster[k].dir;
						int ni = cluster[k].i+di[dir];
						int nj = cluster[k].j+dj[dir];
						int nu = cluster[k].num;
						if(ni==0||ni==N-1||nj==0||nj==N-1) { // 살균되었을 경우
							nu = nu/2;
							if(dir==0||dir==2) {
								dir++;
							}else if(dir==1||dir==3) {
								dir--;
							}
							map[ni][nj][0]=nu;
						}else {
							if(map[ni][nj][1]<nu) { // 기존보다 내가 클떄 내가 살아야함
								map[ni][nj][0]=map[ni][nj][0]+nu; //더한값
								map[ni][nj][1]=nu; // 큰거 작은거 비교
								map[ni][nj][2]=dir; // 방향 
								int loc =map[ni][nj][3];
								if(loc!=0) {
									cluster[loc].num=0;
								}
								map[ni][nj][3]=k; // 전에 있던값
							}else { // 기존보다 내가 작을때 나는 죽어야함
								map[ni][nj][0]=map[ni][nj][0]+nu;
								int loc =map[ni][nj][3];
								if(loc!=0) {
									cluster[loc].num=0;
								}
								cluster[loc].num=map[ni][nj][0];
								cluster[k].num = 0;
							}
						}
						cluster[k].dir=dir;
						cluster[k].i=ni;
						cluster[k].j=nj;
						if(cluster[k].num!=0) {
						cluster[k].num=map[ni][nj][0];
						}
					}
				}
				count++;
			}
			sb.append("#"+test_case+" "+Answer+"\n");
		}
		System.out.println(sb);
	}
	public static void init() {
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				for(int k=0;k<4;k++) {
					map[i][j][k]=0;
				}
			}
		}
	}
	static class Point {
		int i, j, num, dir;

		Point(int i, int j, int num, int dir) {
			this.i = i;
			this.j = j;
			this.num = num;
			this.dir = dir;
		}
	}
}
