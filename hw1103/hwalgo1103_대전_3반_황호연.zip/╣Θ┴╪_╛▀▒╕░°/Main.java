package 백준_야구공;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main {
	static int N, E, OUT;
	static int[][] score;
	static P[] player = new P[10];
	static boolean[] visited = new boolean[10];
	static int Answer = Integer.MIN_VALUE;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());
		score = new int[N][10];
		E = 0;
		for (int i = 0; i < N; i++) {
			st = new StringTokenizer(br.readLine());
			for (int j = 1; j < 10; j++) {
				score[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		PriorityQueue<P> dqueue = new PriorityQueue<P>();
		Queue<P> queue = new LinkedList<P>();
		for (int i = 0; i < N; i++) {
			OUT = 0;
			int cnt = 1;
			
			for (int j = 2; j < 10; j++) {
				dqueue.offer(new P(score[i][j]));
			}
			int size = dqueue.size();
			for(int s=1;s<=size+1;s++) {
				if(s==4) {
					player[4]=new P(score[i][1]);
				}else {
				player[s]=dqueue.poll();
				}
			}
			for(int k=1;k<10;k++) {
				queue.offer(player[k]);
			}
			while (true) {
				if (OUT == 3) {
					break;
				}
				P p = queue.poll();
				if(p.sc==0) {
					queue.offer(p);
					OUT++;
				}else {
					queue.offer(p);
					
				}
			}
		}
	}

	static class P implements Comparable<P> {
		int sc;
		P(int sc) {
			this.sc = sc;
		}
		@Override
		public int compareTo(P o) {
			return this.sc < o.sc ? 1 : -1;
		}
	}
}