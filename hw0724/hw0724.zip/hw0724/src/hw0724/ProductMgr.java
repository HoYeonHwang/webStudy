package hw0724;

public class ProductMgr {
	Product[] product = new Product[100];
	private int index;
	
	private static ProductMgr instance = new ProductMgr();
	private ProductMgr() {
		
	}
	public static ProductMgr getInstance() {
		return instance;
	}
	
	//상품 저장하는 기능 
	public void add(Product p) {
		product[index]=p;
		index++;
	}
	
	//상품 리스트 출력
	public void list() {
		for(int i=0;i<index;i++) {
			System.out.println(product[i].toString());
		}
	}
	
	//상품 번호로 검색
	public void list(int num) {
		for(int i=0;i<index;i++) {
			if(product[i]!=null && product[i].getNumber()==num) {
				System.out.println(product[i].toString());
			}
		}
	}
	
	//상품 번호로 삭제
	public void delete(int num) {
		for(int i=0;i<index;i++) {
			if(product[i]!=null && product[i].getNumber()==num) {
				for(int j=i+1;j<index;j++) {
					product[i]=product[j];
				}
				index--;
			}
		}
	}
	
	//특정 가격 이하의 상품만 검색하는 기능
	public void priceList(int price) {
		for(int i=0;i<index;i++) {
			if(product[i]!=null && product[i].getPrice()<price) {
				System.out.println(product[i].toString());
			}
		}
	}
}
