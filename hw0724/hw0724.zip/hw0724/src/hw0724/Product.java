package hw0724;

public class Product {
	private int number;
	private String name;
	private int price;
	private int grade;

	public Product() {

	}

	public Product(int number, String name, int price, int grade) {

	}
	public String toString() {
		return "상품번호 :"+this.number+" 상품이름 :"+this.name+" 가격 :"+this.price+" 수량 :"+this.grade;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}
}
