package hw0724;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		ProductMgr productmgr = ProductMgr.getInstance();
		int number,name,price,grade;
		Scanner sc = new Scanner(System.in);
		

		while(true) {
			print();
			int select = sc.nextInt();
			switch(select) {
			case 1:
				sc.nextLine();
				Product product = new Product();
				System.out.println("상품 이름 >>");
				product.setName(sc.nextLine());
				System.out.println("상품 번호 >>");
				product.setNumber(sc.nextInt());
				System.out.println("상품 가격 >>");
				product.setPrice(sc.nextInt());
				System.out.println("상품 수량 >>");
				product.setGrade(sc.nextInt());
				sc.nextLine();
				productmgr.add(product);
				break;
			case 2:
				sc.nextLine();
				productmgr.list();
				break;
			case 3:
				sc.nextLine();
				System.out.println("검색할 상품 번호 >>");
				productmgr.list(sc.nextInt());
				sc.nextLine();
				break;
			case 4:
				sc.nextLine();
				System.out.println("삭제할 상품 번호 >>");
				productmgr.delete(sc.nextInt());
				sc.nextLine();
				break;
			case 5:
				sc.nextLine();
				System.out.println("특정 이하의 가격 >>");
				productmgr.priceList(sc.nextInt());
				sc.nextLine();
				break;
			}
		}
	}
	public static void print() {
		System.out.println("<<< 재고 관리 프로그램 >>>");
		System.out.println("1. 상품 저장");
		System.out.println("2. 상품 전체 검색");
		System.out.println("3. 상품 번호 검색");
		System.out.println("4. 상품 삭제");
		System.out.println("5. 특정 가격이하 상품 검색");
	}
}
