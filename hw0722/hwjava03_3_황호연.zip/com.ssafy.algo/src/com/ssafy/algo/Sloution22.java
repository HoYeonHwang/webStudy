package com.ssafy.algo;

import java.util.Scanner;

public class Sloution22 {
	public static void main(String[] args) {
		int N;
		int S_number;
		int Answer = 0;
		int[][] obj;
		Scanner sc = new Scanner(System.in);
		int tast_case = sc.nextInt();
		for (int tast = 0; tast < tast_case; tast++) {
			System.out.print("#" + (tast + 1) + " ");
			Answer=0;
			N = sc.nextInt();
			int[][] map = new int[N][N];
			S_number = sc.nextInt();
			obj = new int[S_number][3];
			for (int i = 0; i < S_number; i++) {
				obj[i][0] = sc.nextInt(); // 시작 i 좌표
				obj[i][1] = sc.nextInt(); // 시작 j 좌표
				obj[i][2] = sc.nextInt(); // 시작 방향
			}
			for (int i = 0; i < S_number; i++) {
				if (obj[i][2] == 1) { // 상
					for (int k = 3; k > 0; k--) {
						if (obj[i][0] - k >= 0) {
							if (map[obj[i][0] - k][obj[i][1]] != 1) {
								obj[i][0] = obj[i][0] - k;
								if (k == 1) {
									map[obj[i][0]][obj[i][1]] = 1;
								}
							}
						} else if (obj[i][0] - k < 0||map[obj[i][0] - k][obj[i][1]] == 1) {
							break;
						}
					}

				} else if (obj[i][2] == 2) { // 하
					for (int k = 3; k > 0; k--) {
						if (obj[i][0] + k <N) {
							if (map[obj[i][0] + k][obj[i][1]] != 1) {
								obj[i][0] = obj[i][0] + k;
								if (k == 1) {
									map[obj[i][0]][obj[i][1]] = 1;
								}
							}
						} else if (obj[i][0] + k >= N||map[obj[i][0] + k][obj[i][1]] == 1) {
							break;
						}
					}
				} else if (obj[i][2] == 3) { // 좌
					for (int k = 3; k > 0; k--) {
						if (obj[i][1] - k >= 0) {
							if (map[obj[i][0]][obj[i][1] - k] != 1) {
								obj[i][1] = obj[i][1] - k;
								if (k == 1) {
									map[obj[i][0]][obj[i][1]] = 1;
								}
							}
						} else if (obj[i][1] - k < 0||map[obj[i][0]][obj[i][1] - k] == 1) {
							break;
						}
					}
				} else if (obj[i][2] == 4) { // 우
					for (int k = 3; k > 0; k--) {
						if (obj[i][1] + k < N) {
							if (map[obj[i][0]][obj[i][1] + k] != 1) {
								obj[i][1] = obj[i][1] + k;
								if (k == 1) {
									map[obj[i][0]][obj[i][1]] = 1;
								}
							}
						} else if (obj[i][1] + k >= N||map[obj[i][0]][obj[i][1] + k] == 1) {
							break;
						}
					}
				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (map[i][j] == 0) {
						map[i][j] = 0;
					}

				}
			}
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if(map[i][j]==1) {
					Answer++;
					}
				}
			}
			System.out.println(Answer);
		}
	}
}
